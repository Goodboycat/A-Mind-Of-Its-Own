const CustomShaders = {
    toonVertex: `
        uniform float uTime;
        uniform vec3 baseColor;
        varying vec3 vNormal;
        varying vec3 vWorldPosition;
        varying vec3 vLocalPosition;
        void main() {
            vNormal = normalize(normalMatrix * normal);
            vLocalPosition = position;
            
            vec3 pos = position;
            
            vec4 worldPos = modelMatrix * vec4(pos, 1.0);
            vWorldPosition = worldPos.xyz;
            gl_Position = projectionMatrix * viewMatrix * worldPos;
        }
    `,
    toonFragment: `
        uniform vec3 baseColor;
        uniform vec3 cameraPos;
        uniform float uTime;
        uniform float uCinematic;
        varying vec3 vNormal;
        varying vec3 vWorldPosition;
        varying vec3 vLocalPosition;
        
        void main() {
            vec3 normal = normalize(vNormal);
            vec3 viewDir = normalize(cameraPos - vWorldPosition);
            float NdotV = max(dot(normal, viewDir), 0.0);
            
            // Seamless smooth vertical gradients ensuring no sudden box divisions
            float heightGrate = clamp((vLocalPosition.y + 1.2) * 0.35, 0.0, 1.0);
            vec3 gradientColor = mix(baseColor * 0.62, baseColor * 1.35, heightGrate);
            
            // Dynamic comic surface noise
            float noise = sin(vLocalPosition.x * 12.0) * cos(vLocalPosition.z * 12.0) * 0.04;
            gradientColor += baseColor * noise;
            
            // Smooth cell shading light banding
            vec3 lightDir = normalize(vec3(0.5, 1.0, 0.3));
            float NdotL = dot(normal, lightDir);
            float intensity = smoothstep(-0.25, 0.25, NdotL) * 0.42 + smoothstep(0.25, 0.75, NdotL) * 0.58;
            vec3 litColor = gradientColor * (0.55 + 0.55 * intensity);
            
            // Vibrant cinematic rim glow
            float rimThreshold = mix(0.18, 0.08, uCinematic);
            float rim = smoothstep(rimThreshold, 0.5, 1.0 - NdotV);
            vec3 rimColor = mix(vec3(0.95, 0.95, 1.0), vec3(1.0, 0.85, 0.6), uCinematic);
            
            // Combine comic shading and rim
            vec3 finalColor = mix(litColor, rimColor, rim * mix(0.25, 0.45, uCinematic));
            
            // Dramatic theatrical grading shift during cinematics (Warm sunset teal & orange feel)
            if (uCinematic > 0.01) {
                vec3 sunsetTone = vec3(1.15, 0.82, 0.65);
                vec3 shadowGrading = vec3(0.5, 0.6, 0.9);
                vec3 graded = mix(finalColor * shadowGrading, finalColor * sunsetTone, intensity);
                finalColor = mix(finalColor, graded, uCinematic);
            }
            
            gl_FragColor = vec4(finalColor, 1.0);
        }
    `
};

function createToonMaterial(hexColor) {
    const color = new THREE.Color(hexColor);
    return new THREE.ShaderMaterial({
        uniforms: {
            baseColor: { value: color },
            cameraPos: { value: new THREE.Vector3() },
            uTime: { value: 0 },
            uCinematic: { value: 0 }
        },
        vertexShader: CustomShaders.toonVertex,
        fragmentShader: CustomShaders.toonFragment
    });
}

function updateShaderUniforms(scene, camera, time, uCinematic) {
    scene.traverse((child) => {
        if (child.isMesh && child.material instanceof THREE.ShaderMaterial) {
            if (child.material.uniforms.cameraPos) {
                child.material.uniforms.cameraPos.value.copy(camera.position);
            }
            if (child.material.uniforms.uTime) {
                child.material.uniforms.uTime.value = time;
            }
            if (child.material.uniforms.uCinematic) {
                child.material.uniforms.uCinematic.value = uCinematic;
            }
        }
    });
}
