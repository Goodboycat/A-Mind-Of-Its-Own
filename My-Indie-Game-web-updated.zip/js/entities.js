// ===========================================================
// ENTITIES — units, combat, mining, archers, projectiles
// ===========================================================

// Arrow / projectile registry (rendered in 3D scene)
var projectiles = (typeof projectiles !== 'undefined') ? projectiles : [];
window.projectiles = projectiles;

// Helper: how often a unit may "say" something so we don't spam bubbles
function _canSpeak(e, key, cooldown) {
    if (!e._speechCD) e._speechCD = {};
    const now = clock ? clock.elapsedTime : 0;
    if (!e._speechCD[key] || now - e._speechCD[key] > cooldown) {
        e._speechCD[key] = now;
        return true;
    }
    return false;
}

// Helper: pick a random line from an array
function _pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

// Convenience: utter a bubble respecting cooldowns and clearing previous ones for same host
function unitSay(e, text, style, key, cooldown) {
    if (!_canSpeak(e, key || 'generic', cooldown || 2.5)) return;
    if (window.triggerSpeechBubble) triggerSpeechBubble(text, e.px, 5.0, e.pz, style || 'attacker', e);
}
window.unitSay = unitSay;

function spawnUnitOnBoard(unitData, x, z, isPlayer) {
    const geo = new THREE.CylinderGeometry(0.5, 0.5, 1.2, 16);
    const mat = createToonMaterial(unitData.color);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, 2, z);

    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 128;
    const ctx = canvas.getContext('2d');
    ctx.font = '70px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(unitData.icon, 64, 64);

    const isBaseEntity = unitData.isBase || (unitData.name && (
        unitData.name.toLowerCase().includes('base') ||
        unitData.name.toLowerCase().includes('keep') ||
        unitData.name.toLowerCase().includes('castle')
    )) || unitData.type === 'base';

    if (!isBaseEntity) {
        ctx.fillStyle = '#000'; ctx.fillRect(14, 100, 100, 10);
        ctx.fillStyle = '#2ed573'; ctx.fillRect(14, 100, 100, 10);
    }

    const tex = new THREE.CanvasTexture(canvas);
    const spriteMat = new THREE.SpriteMaterial({ map: tex, transparent: true });
    const sprite = new THREE.Sprite(spriteMat);
    sprite.position.y = 2.0;
    sprite.scale.set(2,2,2);
    mesh.add(sprite);

    // Dynamic PNG sprite loading
    if (!isBaseEntity && typeof getUnitAssetUrl !== 'undefined') {
        const url = getUnitAssetUrl(unitData.name);
        if (url) {
            const img = new Image();
            img.onload = function() {
                ctx.clearRect(0, 0, 128, 100);
                ctx.drawImage(img, 14, 0, 100, 100);
                // Ensure healthbar is clean and on top
                ctx.fillStyle = '#000'; ctx.fillRect(14, 100, 100, 10);
                ctx.fillStyle = '#2ed573'; ctx.fillRect(14, 100, 100, 10);
                tex.needsUpdate = true;
            };
            img.src = url;
        }
    }

    scene.add(mesh);

    const isRanged = (unitData.role === 'ranged');

    entities.push({
        mesh, sprite, canvasCtx: ctx, tex,
        data: unitData, isPlayer, actionTimer: 0,
        px: x, pz: z, v: new THREE.Vector3(),
        state: 'idle',
        bounceY: 0, bounceYVel: 0,
        kbX: 0, kbZ: 0,
        allyHitCooldown: 0, retaliateTarget: null,
        attackProgress: 0, attackTarget: null, hasHitThisCycle: false,
        // ----- Mining state (replaces the constant-bounce bug) -----
        miningProgress: 0,
        miningSwingT: 0,
        carryAmount: 0,
        // ----- Ranged state -----
        isRanged: isRanged,
        attackRange: isRanged ? 9.0 : 1.5,
        idealRange: isRanged ? 7.0 : 1.2,
        shootCooldown: 0,
        shootAnimT: 0,
        // ----- Speech / mood tracking -----
        _speechCD: {},
        _wasFleeing: false,
        _wasDisobeying: false
    });
}

// ============================================================
// PROJECTILES (arrows fired by ranged units)
// ============================================================
function spawnArrow(fromX, fromY, fromZ, target, dmg, ownerIsPlayer) {
    const shaft = new THREE.Mesh(
        new THREE.CylinderGeometry(0.05, 0.05, 1.2, 6),
        new THREE.MeshBasicMaterial({ color: '#3a2a18' })
    );
    shaft.rotation.z = Math.PI / 2; // lay it horizontally; we'll re-orient below
    const head = new THREE.Mesh(
        new THREE.ConeGeometry(0.12, 0.3, 6),
        new THREE.MeshBasicMaterial({ color: '#dcdcdc' })
    );
    head.position.x = 0.75;
    head.rotation.z = -Math.PI / 2;
    const group = new THREE.Group();
    group.add(shaft); group.add(head);
    group.position.set(fromX, fromY, fromZ);
    scene.add(group);

    projectiles.push({
        mesh: group,
        x: fromX, y: fromY, z: fromZ,
        target: target,
        speed: 28,
        dmg: dmg,
        ownerIsPlayer: ownerIsPlayer,
        age: 0,
        maxAge: 2.5
    });
    // Pass shoot position so sound attenuates by distance from camera
    if (window.SFX) SFX.play('arrowShoot', { x: fromX, z: fromZ });
}
window.spawnArrow = spawnArrow;

function updateProjectiles(dt) {
    for (let i = projectiles.length - 1; i >= 0; i--) {
        const p = projectiles[i];
        p.age += dt;
        // Resolve target position (may be entity or base or {x,z})
        let tx, ty, tz, targetAlive = true;
        if (p.target && p.target.data) {
            if (p.target.data.currentHp <= 0) targetAlive = false;
            tx = p.target.px; ty = (p.target.mesh ? p.target.mesh.position.y + 0.5 : 1.5); tz = p.target.pz;
        } else if (p.target && p.target.group) {
            if (p.target.destroyed) targetAlive = false;
            tx = p.target.x; ty = 3.0; tz = p.target.z;
        } else if (p.target) {
            tx = p.target.x; ty = 1.5; tz = p.target.z;
        }

        if (!targetAlive || p.age > p.maxAge) {
            scene.remove(p.mesh);
            projectiles.splice(i, 1); continue;
        }
        const dx = tx - p.x, dy = ty - p.y, dz = tz - p.z;
        const dist = Math.hypot(dx, dy, dz);
        if (dist < 0.9) {
            // HIT
            if (p.target && p.target.data) {
                // Friendly fire guard
                if ((p.target.isPlayer === p.ownerIsPlayer)) {
                    // skip damage; arrows whiff
                } else {
                    p.target.data.currentHp -= p.dmg;
                    let kbx = (dx / (dist || 1)) * 2.5, kbz = (dz / (dist || 1)) * 2.5;
                    p.target.kbX = kbx; p.target.kbZ = kbz;
                    if (window.triggerLivelyEmoji) triggerLivelyEmoji('🎯', p.target.px, 2.5, p.target.pz, 'normal_hit', p.target);
                    if (window.triggerFloatingText) triggerFloatingText(p.dmg.toString(), p.target.px, 2.5, p.target.pz, '#ff4757');
                }
            } else if (p.target && p.target.group && window.damageBase) {
                if (p.target.isPlayer !== p.ownerIsPlayer) damageBase(p.target, p.dmg, null);
            }
            scene.remove(p.mesh);
            projectiles.splice(i, 1);
            continue;
        }
        const step = Math.min(dist, p.speed * dt);
        p.x += (dx / dist) * step;
        p.y += (dy / dist) * step;
        p.z += (dz / dist) * step;
        p.mesh.position.set(p.x, p.y, p.z);
        // Orient arrow toward its travel direction
        p.mesh.lookAt(tx, ty, tz);
        p.mesh.rotation.y += Math.PI / 2; // shaft is along X axis
    }
}
window.updateProjectiles = updateProjectiles;

// ============================================================
// MAIN ENTITY UPDATE
// ============================================================
function updateEntities(dt) {
    entities.forEach(e => {
        if (e.data.currentHp <= 0) return;

        if (e.allyHitCooldown > 0) e.allyHitCooldown -= dt;
        if (e.shootCooldown > 0) e.shootCooldown -= dt;
        if (e.shootAnimT > 0) e.shootAnimT -= dt;

        // Procedural movement with realism (Bouncing)
        if (e.bounceYVel > 0 || e.bounceY > 0) {
            e.bounceY += e.bounceYVel * dt;
            e.bounceYVel -= 40 * dt;
            if (e.bounceY <= 0) {
                e.bounceY = 0; e.bounceYVel = 0;
                e.mesh.scale.set(1.4, 0.6, 1.4); // Squash on landing
            }
        }

        if (Math.abs(e.kbX) > 0.01 || Math.abs(e.kbZ) > 0.01) {
            let nextX = e.px + e.kbX * dt;
            let nextZ = e.pz + e.kbZ * dt;
            let gridX = Math.floor(nextX + MAP_SIZE/2);
            let gridZ = Math.floor(nextZ + MAP_SIZE/2);
            if (gridX >= 0 && gridX < MAP_SIZE && gridZ >= 0 && gridZ < MAP_SIZE && (mapGrid[gridX][gridZ] === 2 || mapGrid[gridX][gridZ] === 4 || mapGrid[gridX][gridZ] === 5)) {
                e.kbX = -e.kbX * 0.6; e.kbZ = -e.kbZ * 0.6;
                triggerLivelyEmoji('💥', e.px, 2.5, e.pz, 'normal_hit', e);
            } else {
                e.px = Math.max(-MAP_SIZE/2 + 0.5, Math.min(MAP_SIZE/2 - 0.5, nextX));
                e.pz = Math.max(-MAP_SIZE/2 + 0.5, Math.min(MAP_SIZE/2 - 0.5, nextZ));
            }
            e.kbX *= Math.exp(-6 * dt);
            e.kbZ *= Math.exp(-6 * dt);
        }

        e.actionTimer += dt;

        if (e.state === 'attack') {
            e.attackProgress += dt * 1.5;
            let t = e.attackProgress;
            let scaleX = 1.0, scaleY = 1.0, scaleZ = 1.0, pushX = 0, pushZ = 0;

            if (t < 0.4) {
                let p = t / 0.4;
                scaleX = 1.3 - p * 0.3; scaleY = 0.6 + p * 0.7; scaleZ = 1.3 - p * 0.3;
                if (e.attackTarget) {
                    let d = Math.hypot(e.px - e.attackTarget.px, e.pz - e.attackTarget.pz) || 1;
                    pushX = ((e.px - e.attackTarget.px) / d) * 0.6 * p;
                    pushZ = ((e.pz - e.attackTarget.pz) / d) * 0.6 * p;
                }
            } else if (t < 0.7) {
                let p = (t - 0.4) / 0.3;
                scaleX = 0.5 + p * 0.2; scaleY = 1.6 - p * 0.8; scaleZ = 0.5 + p * 0.2;
                if (e.attackTarget) {
                    let d = Math.hypot(e.attackTarget.px - e.px, e.attackTarget.pz - e.pz) || 1;
                    pushX = ((e.attackTarget.px - e.px) / d) * (-0.6 + 1.8 * p);
                    pushZ = ((e.attackTarget.pz - e.pz) / d) * (-0.6 + 1.8 * p);
                }
            } else {
                let p = (t - 0.7) / 0.3;
                scaleX = 1.4 - p * 0.4; scaleY = 0.5 + p * 0.5; scaleZ = 1.4 - p * 0.4;
                if (e.attackTarget) {
                    let d = Math.hypot(e.attackTarget.px - e.px, e.attackTarget.pz - e.pz) || 1;
                    pushX = ((e.attackTarget.px - e.px) / d) * 1.2 * (1.0 - p);
                    pushZ = ((e.attackTarget.pz - e.pz) / d) * 1.2 * (1.0 - p);
                }
            }

            e.mesh.scale.set(scaleX, scaleY, scaleZ);
            e.mesh.position.x = e.mesh.position.x * 0.82 + (e.px + pushX) * 0.18;
            e.mesh.position.z = e.mesh.position.z * 0.82 + (e.pz + pushZ) * 0.18;

            if (t >= 0.7 && !e.hasHitThisCycle) {
                e.hasHitThisCycle = true;
                if (e.attackTarget && e.attackTarget.data.currentHp > 0) {
                    let enemy = e.attackTarget;
                    const prevHp = enemy.data.currentHp;
                    enemy.data.currentHp -= e.data.atk;
                    // Play hit sound for hits relevant to the player (own attacks or enemies hitting player units)
                    // Hit sound emitted at the victim's position
                    if (window.SFX) SFX.play('attackHit', { entity: enemy });
                    if (window.SFX && enemy.data.currentHp <= 0 && prevHp > 0) SFX.play('unitDie', { entity: enemy });
                    let targetIsAlly = (e.isPlayer === enemy.isPlayer);
                    let dx = enemy.px - e.px, dz = enemy.pz - e.pz, len = Math.hypot(dx, dz) || 1;

                    if (targetIsAlly) {
                        enemy.kbX = (dx / len) * 15.0; enemy.kbZ = (dz / len) * 15.0;
                        enemy.bounceYVel = 14.0; enemy.state = 'idle';
                        enemy.retaliateTarget = e; enemy.actionTimer = 0.8;
                        e.allyHitCooldown = 5.0;
                        triggerSpeechBubble("OW! HEY!", enemy.px, 5.0, enemy.pz, 'victim', enemy);
                        triggerSpeechBubble("MY BAD!", e.px, 4.5, e.pz, 'attacker', e);
                        triggerLivelyEmoji('😡', enemy.px, 2.2, enemy.pz, 'lively_angry', enemy);
                    } else {
                        enemy.kbX = (dx / len) * 4.5; enemy.kbZ = (dz / len) * 4.5;
                        triggerLivelyEmoji('💥', enemy.px, 2.5, enemy.pz, 'normal_hit', enemy);
                        triggerFloatingText(e.data.atk.toString(), enemy.px, 2.5, enemy.pz, '#ff4757');
                    }
                }
            }
            if (t >= 1.0) { e.state = 'idle'; e.attackTarget = null; }
        } else {
            let tx = e.px, tz = e.pz, speedMult = 1.0;
            let nearestEnemy = null, enemyDist = 999, nearestAlly = null, allyDist = 999;

            entities.forEach(other => {
                if (other === e || other.data.currentHp <= 0) return;
                const d = Math.hypot(other.px - e.px, other.pz - e.pz);
                if (other.isPlayer !== e.isPlayer) {
                    if (d < enemyDist) { enemyDist = d; nearestEnemy = other; }
                } else if (d < allyDist) { allyDist = d; nearestAlly = other; }
            });

            // Loyalty obedience check
            const behavesLoyally = (e.data.loyalty >= 45 || e.data.type === 'machine' || (Math.random() * 100 < e.data.loyalty));

            if (e.isPlayer && latestEmoji === '💖' && Math.random() < 0.1) {
                e.data.loyalty = Math.min(100, e.data.loyalty + 5);
            }

            // ---- Disobey grumbling (now uses cooldown + personality lines) ----
            if (e.order && !behavesLoyally) {
                if (_canSpeak(e, 'disobey', 3.5) && Math.random() < 0.45) {
                    const lines = (PERSONALITY_LINES[e.data.type] && PERSONALITY_LINES[e.data.type].disobey) || [];
                    const generic = ["Why should I?", "Make me!", "Not happening.", "I won't!", "Pfft, no.", "You're not the boss of me!"];
                    const pool = (lines.length ? lines : generic);
                    triggerSpeechBubble(_pick(pool), e.px, 5.0, e.pz, 'victim', e);
                    triggerLivelyEmoji('😡', e.px, 2.2, e.pz, 'lively_angry', e);
                }
                e._wasDisobeying = true;
            }

            let combatTarget = e.retaliateTarget && e.retaliateTarget.data.currentHp > 0 ? e.retaliateTarget : nearestEnemy;
            let canDisobeyHitAlly = (!behavesLoyally && e.allyHitCooldown <= 0);
            if (canDisobeyHitAlly && e.data.type === 'violent' && allyDist < enemyDist && nearestAlly) {
                combatTarget = nearestAlly;
            }

            let activeOrder = behavesLoyally ? e.order : null;

            // ============== MINING ORDER (BUG FIXED) ==============
            if (activeOrder === 'mine') {
                e.carryAmount = e.carryAmount || 0;
                if (e.carryAmount >= 3) {
                    // Head to base to deliver
                    let hx = 0, hz = 38;
                    if (!e.isPlayer) {
                        let bestBase = null, minBD = 999;
                        enemyBases.forEach(b => {
                            if (!b.destroyed) {
                                const dist = Math.hypot(b.x - e.px, b.z - e.pz);
                                if (dist < minBD) { minBD = dist; bestBase = b; }
                            }
                        });
                        if (bestBase) { hx = bestBase.x; hz = bestBase.z; } else { hx = 0; hz = -42; }
                    }
                    tx = hx; tz = hz;
                    let keepDist = Math.hypot(hx - e.px, hz - e.pz);
                    if (keepDist < 3.2) {
                        const reward = e.carryAmount * REFINED_PER_CHUNK;
                        if (e.isPlayer) {
                            gems += reward;
                            const gemEl = document.getElementById('gem-count');
                            if (gemEl) gemEl.innerText = gems;
                            if (window.logEvent) logEvent(`💠 Delivered & refined +${reward} gems!`, '#2ed573');
                            // Refining happens at the keep — emit at the keep position
                            if (window.SFX) SFX.play('gemRefined', { x: hx, z: hz });
                        } else {
                            enemyGems += reward;
                            if (window.logEvent) logEvent(`💠 AI refined +${reward} gems!`, '#ff4757');
                        }
                        if (window.triggerFloatingText) triggerFloatingText('💎 +' + reward, e.px, 2.5, e.pz, '#1dd1a1');
                        unitSay(e, "Refined! 💎", 'attacker', 'delivered', 4);
                        e.carryAmount = 0;
                        e.miningProgress = 0;
                    }
                } else {
                    // Look for nearest deposit / pile, but STICK to the current target
                    // so we don't oscillate between two deposits at equal distance.
                    if (!e._mineTarget || e._mineTarget._gone) {
                        let dep = window.findNearestDeposit ? findNearestDeposit(e.px, e.pz) : null;
                        let pile = window.findNearestDroppedPile ? findNearestDroppedPile(e.px, e.pz) : null;
                        let targetRes = null;
                        let isPile = false;
                        let resDist = 999;
                        if (dep) { targetRes = dep; resDist = Math.hypot(dep.x - e.px, dep.z - e.pz); }
                        if (pile) {
                            let pd = Math.hypot(pile.x - e.px, pile.z - e.pz);
                            if (pd < resDist) { targetRes = pile; resDist = pd; isPile = true; }
                        }
                        e._mineTarget = targetRes;
                        e._mineIsPile = isPile;
                    }
                    const targetRes = e._mineTarget;
                    const isPile = e._mineIsPile;

                    if (targetRes && ((isPile && targetRes.amount > 0) || (!isPile && targetRes.remaining > 0))) {
                        tx = targetRes.x; tz = targetRes.z;
                        const resDist = Math.hypot(tx - e.px, tz - e.pz);
                        if (resDist < 1.6) {
                            // === MINING IN PLACE — NO MORE JUMP-FLY BUG ===
                            // Anchor position so they don't drift; play a "swing" animation only.
                            e.state = 'mining';
                            speedMult = 0;
                            e.miningProgress += dt;
                            e.miningSwingT = (e.miningSwingT || 0) + dt;
                            // Face the deposit
                            const fx = targetRes.x - e.px, fz = targetRes.z - e.pz;
                            if (Math.hypot(fx, fz) > 0.05) {
                                const desiredYaw = Math.atan2(fx, fz);
                                e.mesh.rotation.y = desiredYaw;
                            }
                            // Occasional pick-swing emoji (every ~0.9s, not a jump!)
                            if (e.miningSwingT > 0.9) {
                                e.miningSwingT = 0;
                                if (window.triggerLivelyEmoji) triggerLivelyEmoji('⛏️', e.px, 2.2, e.pz, 'normal_hit', e);
                                if (Math.random() < 0.25) unitSay(e, _pick(PERSONALITY_LINES[e.data.type]?.mine || ["*chip*", "*clang*"]), 'attacker', 'mining_say', 6);
                                // Only play swing sound for the player's units (avoid AI spam)
                                // Pick-swing sound emitted at the miner's position
                                if (window.SFX) SFX.play('mineHit', { entity: e });
                            }
                            if (e.miningProgress >= MINING_DURATION) {
                                e.miningProgress = 0;
                                e.carryAmount += 1;
                                if (window.triggerFloatingText) triggerFloatingText('💠 +1', e.px, 2.3, e.pz, '#5fdfff');
                                if (window.SFX) SFX.play('gemPickup', { entity: e });
                                if (isPile) {
                                    targetRes.amount -= 1;
                                    if (targetRes.amount <= 0) {
                                        scene.remove(targetRes.mesh);
                                        const pIdx = droppedGems.indexOf(targetRes);
                                        if (pIdx >= 0) droppedGems.splice(pIdx, 1);
                                        targetRes._gone = true;
                                        e._mineTarget = null;
                                        // === STOP MINING ANIMATION IMMEDIATELY when stone disappears ===
                                        e.state = 'idle';
                                        e.miningSwingT = 0;
                                        e.miningProgress = 0;
                                        e.mesh.rotation.x = 0;
                                        e.mesh.rotation.z = 0;
                                        if (window.SFX) SFX.play('depositDepleted', { x: targetRes.x, z: targetRes.z });
                                    }
                                } else {
                                    targetRes.remaining -= 1;
                                    if (targetRes.remaining <= 0) {
                                        targetRes._gone = true;
                                        e._mineTarget = null;
                                        // === STOP MINING ANIMATION IMMEDIATELY when mineral stone disappears ===
                                        e.state = 'idle';
                                        e.miningSwingT = 0;
                                        e.miningProgress = 0;
                                        e.mesh.rotation.x = 0;
                                        e.mesh.rotation.z = 0;
                                        if (window.SFX) SFX.play('depositDepleted', { x: targetRes.x, z: targetRes.z });
                                    }
                                }
                            }
                        } else {
                            // Target still has resources but we're not in range — make sure we're not stuck in mining pose while walking
                            if (e.state === 'mining') {
                                e.state = 'idle';
                                e.miningSwingT = 0;
                                e.mesh.rotation.x = 0;
                                e.mesh.rotation.z = 0;
                            }
                        }
                    } else {
                        // No resource available — drop back to default behavior, ensure mining animation halts
                        e._mineTarget = null;
                        if (e.state === 'mining') {
                            e.state = 'idle';
                            e.miningSwingT = 0;
                            e.miningProgress = 0;
                            e.mesh.rotation.x = 0;
                            e.mesh.rotation.z = 0;
                        }
                        if (combatTarget) { tx = combatTarget.px; tz = combatTarget.pz; }
                    }
                }
            } else if (activeOrder === 'defend') {
                let hx = e.isPlayer ? 0 : 0;
                let hz = e.isPlayer ? 30 : -30;
                let baseDist = Math.hypot(hx - e.px, hz - e.pz);
                if (combatTarget && (enemyDist < 7 || Math.hypot(combatTarget.px - hx, combatTarget.pz - hz) < 12)) {
                    tx = combatTarget.px; tz = combatTarget.pz;
                } else if (baseDist > 4) {
                    tx = hx + (Math.sin(e.data.id || 0) * 3);
                    tz = hz + (e.isPlayer ? -2 : 2);
                } else {
                    tx = e.px; tz = e.pz;
                }
            } else if (activeOrder === 'retreat') {
                let hx = e.isPlayer ? 0 : 0;
                let hz = e.isPlayer ? 50 : -50;
                tx = hx + (Math.sin(e.data.id || 0) * 4);
                tz = hz;
                speedMult = 1.35;
                if (nearestEnemy && enemyDist < 2.5) {
                    tx = nearestEnemy.px; tz = nearestEnemy.pz;
                }
            } else if (activeOrder === 'hold') {
                let ox = e.orderTarget ? e.orderTarget.x : e.px;
                let oz = e.orderTarget ? e.orderTarget.z : e.pz;
                let holdDist = Math.hypot(ox - e.px, oz - e.pz);
                if (combatTarget && enemyDist < (e.isRanged ? e.attackRange : 2.2)) {
                    tx = combatTarget.px; tz = combatTarget.pz;
                } else if (holdDist > 1.2) {
                    tx = ox; tz = oz;
                } else {
                    tx = e.px; tz = e.pz;
                }
            } else if (activeOrder === 'attack' && e.orderTarget) {
                let ox = e.orderTarget.x;
                let oz = e.orderTarget.z;
                let targetDist = Math.hypot(ox - e.px, oz - e.pz);
                if (combatTarget && enemyDist < (e.isRanged ? e.attackRange : 4.5)) {
                    tx = combatTarget.px; tz = combatTarget.pz;
                } else if (targetDist > 1.2) {
                    tx = ox; tz = oz;
                } else {
                    e.order = null;
                    if (combatTarget) { tx = combatTarget.px; tz = combatTarget.pz; }
                }
            } else if (activeOrder === 'ping' && e.orderTarget) {
                tx = e.orderTarget.x; tz = e.orderTarget.z;
                if (Math.hypot(tx - e.px, tz - e.pz) < 1.2) {
                    e.order = null;
                }
            } else {
                // DEFAULT COMBAT / AI
                if (e.data.type === 'coward' && enemyDist < 4) {
                    e.state = 'flee';
                    tx = e.px + (e.px - nearestEnemy.px);
                    tz = e.pz + (e.pz - nearestEnemy.pz);
                    speedMult = 1.6;
                    // Coward fleeing bubble
                    if (_canSpeak(e, 'flee', 3)) {
                        const lines = ["AAAH!", "Run away!", "Help me!", "Mama!", "I quit!"];
                        triggerSpeechBubble(_pick(lines), e.px, 5.0, e.pz, 'victim', e);
                        triggerLivelyEmoji('😱', e.px, 2.2, e.pz, 'lively_angry', e);
                    }
                    e._wasFleeing = true;
                } else {
                    if (canDisobeyHitAlly && e.data.type === 'violent' && allyDist < enemyDist && nearestAlly) combatTarget = nearestAlly;
                    if (e.isPlayer && currentPing && e.data.type !== 'violent') { tx = currentPing.x; tz = currentPing.z; }
                    else if (e.isPlayer && latestEmoji === '🏃' && e.data.type !== 'machine') { tx = e.px; tz = e.pz + 10; }
                    else if (combatTarget) { tx = combatTarget.px; tz = combatTarget.pz; }
                }
            }

            let targetDist = combatTarget ? Math.hypot(combatTarget.px - e.px, combatTarget.pz - e.pz) : 999;

            // ============== RANGED KITING & SHOOTING ==============
            // Archers stay at distance; if too close, back up. If in range and stationary, fire arrow.
            if (e.isRanged && combatTarget && targetDist < e.attackRange * 1.3) {
                if (targetDist < e.idealRange - 0.8) {
                    // Too close — back away from enemy
                    const dxBack = e.px - combatTarget.px;
                    const dzBack = e.pz - combatTarget.pz;
                    const lenBack = Math.hypot(dxBack, dzBack) || 1;
                    tx = e.px + (dxBack / lenBack) * 6;
                    tz = e.pz + (dzBack / lenBack) * 6;
                    speedMult = 1.2;
                } else if (targetDist > e.attackRange) {
                    // Too far — close in slightly
                    tx = combatTarget.px; tz = combatTarget.pz;
                } else {
                    // In sweet spot — hold position and shoot
                    tx = e.px; tz = e.pz;
                }
            }

            // Clamp the movement target so units don't try to walk off the visible map
            // (cowards fleeing away from an enemy, retreat-to-z=±50, off-map order taps, etc.)
            const _tgtLimit = (typeof ARENA_LIMIT !== 'undefined') ? ARENA_LIMIT : (MAP_SIZE/2 - 2);
            if (tx >  _tgtLimit) tx =  _tgtLimit;
            if (tx < -_tgtLimit) tx = -_tgtLimit;
            if (tz >  _tgtLimit) tz =  _tgtLimit;
            if (tz < -_tgtLimit) tz = -_tgtLimit;

            const dx = tx - e.px, dz = tz - e.pz, dist = Math.hypot(dx, dz);

            // Decide whether the unit should move this frame
            const wantsToShoot = (e.isRanged && combatTarget && targetDist >= e.idealRange - 0.8 && targetDist <= e.attackRange);
            const shouldStandStill = (e.state === 'mining') || (wantsToShoot && e.shootCooldown <= 0.05);

            // Track whether unit is actively mining THIS FRAME (set by mining block above when in range of a live deposit)
            const isActivelyMining = (e.state === 'mining' && e._mineTarget && !e._mineTarget._gone);
            if (dist > 0.1 && e.state !== 'attack' && !isActivelyMining && !shouldStandStill) {
                let vx = (dx/dist) * e.data.speed * speedMult * dt;
                let vz = (dz/dist) * e.data.speed * speedMult * dt;

                let gx = Math.floor(e.px + MAP_SIZE/2), gz = Math.floor(e.pz + MAP_SIZE/2);

                if (gx>=0 && gx<MAP_SIZE && gz>=0 && gz<MAP_SIZE && mapGrid[gx][gz] === 1) {
                     if (e.bounceY === 0 && Math.random() < 0.22) { e.bounceYVel = 14.0; triggerFloatingText("SPLASH!", e.px, 2.5, e.pz, '#1e90ff'); }
                     if (e.bounceY > 0.1) { vx *= 0.85; vz *= 0.85; } else { vx *= 0.4; vz *= 0.4; }
                }

                let nx = Math.floor(e.px + vx + MAP_SIZE/2), nz = Math.floor(e.pz + vz + MAP_SIZE/2);
                let isFacingObstacle = (nx>=0 && nx<MAP_SIZE && nz>=0 && nz<MAP_SIZE && (mapGrid[nx][nz] === 2 || mapGrid[nx][nz] === 3 || mapGrid[nx][nz] === 4 || mapGrid[nx][nz] === 5));

                // Only LEAP for traversable height obstacles (tree=4, highland=3), NOT base(5) or mountain(2)
                const isLeapable = (nx>=0 && nx<MAP_SIZE && nz>=0 && nz<MAP_SIZE && (mapGrid[nx][nz] === 3 || mapGrid[nx][nz] === 4));
                if (isFacingObstacle && isLeapable && e.bounceY === 0 && e.bounceYVel === 0) {
                    e.bounceYVel = 16.0;
                }

                if (isFacingObstacle) {
                    if (e.bounceY > 0.35 && isLeapable) { e.px += vx; e.pz += vz; }
                    else {
                        // Slide along
                        let noX = Math.floor(e.px + vx + MAP_SIZE/2), noZ = Math.floor(e.pz + MAP_SIZE/2);
                        if (noX>=0 && noX<MAP_SIZE && mapGrid[noX][noZ] !== 2 && mapGrid[noX][noZ] !== 4 && mapGrid[noX][noZ] !== 5) e.px += vx;
                        else {
                            let noX2 = Math.floor(e.px + MAP_SIZE/2), noZ2 = Math.floor(e.pz + vz + MAP_SIZE/2);
                            if (noZ2>=0 && noZ2<MAP_SIZE && mapGrid[noX2][noZ2] !== 2 && mapGrid[noX2][noZ2] !== 4 && mapGrid[noX2][noZ2] !== 5) e.pz += vz;
                        }
                    }
                } else { e.px += vx; e.pz += vz; }

                // ===== INVISIBLE ARENA BORDER =====
                // Hard-clamp position so a unit can never wander off the visible terrain.
                // (Without this, fleeing cowards / retreat-target seekers / off-map order-targets
                //  could march away forever.)
                const _limit = (typeof ARENA_LIMIT !== 'undefined') ? ARENA_LIMIT : (MAP_SIZE/2 - 2);
                if (e.px >  _limit) { e.px =  _limit; }
                if (e.px < -_limit) { e.px = -_limit; }
                if (e.pz >  _limit) { e.pz =  _limit; }
                if (e.pz < -_limit) { e.pz = -_limit; }

                if(e.state !== 'flee') e.state = 'walk';
            } else if (e.state !== 'attack' && !isActivelyMining) {
                // Allow stale 'mining' state to clear when the unit is no longer actively at a deposit.
                // (Active mining is re-asserted every frame inside the 'mine' order block when in range of a live deposit.)
                e.state = 'idle';
            }

            // ============== ATTACK TRIGGER ==============
            // Melee: contact range
            if (!e.isRanged && combatTarget && targetDist < 1.5 && e.actionTimer > 1.2) {
                e.state = 'attack'; e.attackProgress = 0.0; e.attackTarget = combatTarget;
                e.hasHitThisCycle = false; e.actionTimer = 0;
            }
            // Ranged: must be standing still, target in range, cooldown ready
            if (e.isRanged && combatTarget && targetDist <= e.attackRange && targetDist >= e.idealRange - 1.5 && e.shootCooldown <= 0 && e.state !== 'walk' && e.state !== 'flee') {
                // Fire an arrow
                const groundY = (e.mesh.position.y || 1.5) + 0.3;
                spawnArrow(e.px, groundY, e.pz, combatTarget, e.data.atk, e.isPlayer);
                e.shootCooldown = 1.4; // seconds between shots
                e.shootAnimT = 0.35;
                e.actionTimer = 0;
                // Face target
                const fx = combatTarget.px - e.px, fz = combatTarget.pz - e.pz;
                if (Math.hypot(fx, fz) > 0.05) e.mesh.rotation.y = Math.atan2(fx, fz);
                // Pull-back squash
                e.mesh.scale.set(0.85, 1.18, 0.85);
                if (Math.random() < 0.3) unitSay(e, _pick(["Loose!", "Twang!", "*nock*", "Target!"]), 'attacker', 'shoot', 5);
            }

            // ============== BASE ATTACKS (close enough) ==============
            if (window.damageBase) {
                for (const b of bases) {
                    if (b.destroyed) continue;
                    if (b.isPlayer === e.isPlayer) continue; // can't attack own
                    const bd = Math.hypot(b.x - e.px, b.z - e.pz);
                    // Melee tags base
                    if (!e.isRanged && bd < b.radius + 1.3 && e.actionTimer > 1.2 && e.state !== 'mining') {
                        const dmg = (e.data.role === 'siege') ? e.data.atk * 3 : Math.max(2, Math.floor(e.data.atk * 0.6));
                        damageBase(b, dmg, e);
                        e.actionTimer = 0;
                        e.state = 'attack'; e.attackProgress = 0.0;
                        e.attackTarget = { px: b.x, pz: b.z, data: { currentHp: 1 }, isPlayer: b.isPlayer }; // dummy for swing anim
                        e.hasHitThisCycle = true; // already applied
                    }
                    // Archer shoots base if no closer enemy and base in range
                    if (e.isRanged && bd <= e.attackRange && (!combatTarget || targetDist > bd + 1) && e.shootCooldown <= 0 && e.state !== 'walk' && e.state !== 'flee') {
                        const groundY = (e.mesh.position.y || 1.5) + 0.3;
                        spawnArrow(e.px, groundY, e.pz, b, Math.max(3, Math.floor(e.data.atk * 0.7)), e.isPlayer);
                        e.shootCooldown = 1.4;
                        e.shootAnimT = 0.35;
                        e.actionTimer = 0;
                        const fx = b.x - e.px, fz = b.z - e.pz;
                        if (Math.hypot(fx, fz) > 0.05) e.mesh.rotation.y = Math.atan2(fx, fz);
                    }
                }
            }

            // ============== STATE-CHANGE BUBBLES (clears flags) ==============
            if (e.state !== 'flee' && e._wasFleeing) e._wasFleeing = false;
            if (behavesLoyally && e._wasDisobeying) e._wasDisobeying = false;
        }

        // ============== VISUAL UPDATES ==============
        if (e.state !== 'attack') {
            e.mesh.scale.lerp(new THREE.Vector3(1,1,1), 0.15);
            e.mesh.position.lerp(new THREE.Vector3(e.px, e.mesh.position.y, e.pz), 0.15);

            if (e.state === 'walk' || e.state === 'flee') {
                let walkCycle = clock.elapsedTime * 12 * e.data.speed;
                e.mesh.rotation.x = Math.sin(walkCycle) * 0.22;
                e.mesh.rotation.z = Math.cos(walkCycle) * 0.1;
                if (Math.hypot(e.px - e.mesh.position.x, e.pz - e.mesh.position.z) > 0.01) {
                    e.mesh.rotation.y = Math.atan2(e.px - e.mesh.position.x, e.pz - e.mesh.position.z);
                }
            } else if (e.state === 'mining') {
                // Stationary swing — slight back-and-forth pitch only
                const swing = Math.sin(clock.elapsedTime * 8) * 0.35;
                e.mesh.rotation.x = swing;
                e.mesh.rotation.z = 0;
                // Vertical squash with the swing for "chop" feel
                e.mesh.scale.y = 1.0 - Math.abs(Math.sin(clock.elapsedTime * 8)) * 0.18;
            } else if (e.shootAnimT > 0) {
                // Ranged: post-shot recoil
                e.mesh.rotation.x = -0.25 * (e.shootAnimT / 0.35);
                e.mesh.rotation.z = 0;
            } else {
                e.mesh.rotation.x = 0; e.mesh.rotation.z = 0;
                let idleCycle = clock.elapsedTime * 4;
                e.mesh.scale.y = 1.0 + Math.sin(idleCycle) * 0.06;
            }
        }

        let groundH = 1.0;
        let gx = Math.max(0, Math.min(MAP_SIZE-1, Math.floor(e.px + MAP_SIZE/2)));
        let gz = Math.max(0, Math.min(MAP_SIZE-1, Math.floor(e.pz + MAP_SIZE/2)));
        if(mapGrid[gx] && mapGrid[gx][gz] === 3) groundH = 2.0;

        // No walk bob when mining — that's what caused the "jumping flight" bug.
        if (e.state === 'walk' || e.state === 'flee') groundH += Math.abs(Math.sin(clock.elapsedTime * 12 * e.data.speed)) * 0.45;
        e.mesh.position.y = groundH + e.bounceY;

        e.canvasCtx.clearRect(0, 80, 128, 40);
        const isBaseEntity = e.isBase || e.data?.isBase || (e.data?.name && (
            e.data.name.toLowerCase().includes('base') ||
            e.data.name.toLowerCase().includes('keep') ||
            e.data.name.toLowerCase().includes('castle')
        )) || e.data?.type === 'base';

        if (!isBaseEntity) {
            e.canvasCtx.fillStyle = '#000'; e.canvasCtx.fillRect(14, 100, 100, 10);
            e.canvasCtx.fillStyle = e.isPlayer ? '#2ed573' : '#ff4757';
            e.canvasCtx.fillRect(14, 100, 100 * Math.max(0, e.data.currentHp / e.data.maxHp), 10);
        }
        e.tex.needsUpdate = true;
    });

    for (let i = entities.length - 1; i >= 0; i--) {
        const ent = entities[i];
        if (ent.data.currentHp <= 0) {
            scene.remove(ent.mesh);
            triggerFloatingText("💀", ent.px, 2, ent.pz, '#fff');

            // Drop unrefined gems on death
            if (ent.carryAmount > 0 && window.spawnDroppedGems) {
                spawnDroppedGems(ent.px, ent.pz, ent.carryAmount, ent.isPlayer);
                triggerFloatingText("💠 GEMS DROPPED!", ent.px, 2.5, ent.pz, '#5fdfff');
            }
            entities.splice(i, 1);
        }
    }
}
