function setPhaseText(title, sub, btnText) {
    document.getElementById('phase-text').innerText = title;
    document.getElementById('phase-sub').innerText = sub;
    
    let color = "#10ac84";
    if (title.includes("ENEMY")) color = "#2e86de";
    else if (title.includes("COMBAT")) color = "#ff4757";
    triggerCinematicPhaseText(title, color);
    
    const banner = document.getElementById('phase-banner');
    const titleEl = document.getElementById('phase-text');
    
    if (banner && titleEl) {
        if (title.includes("PREP") && !title.includes("ENEMY")) {
            banner.style.borderColor = "#10ac84"; titleEl.style.color = "#10ac84";
            banner.style.boxShadow = "4px 4px 0px #000000, 0 4px 15px rgba(16, 172, 132, 0.3)";
        } else if (title.includes("ENEMY")) {
            banner.style.borderColor = "#2e86de"; titleEl.style.color = "#2e86de";
            banner.style.boxShadow = "4px 4px 0px #000000, 0 4px 15px rgba(46, 134, 222, 0.3)";
        } else if (title.includes("COMBAT")) {
            banner.style.borderColor = "#ff4757"; titleEl.style.color = "#ff4757";
            banner.style.boxShadow = "4px 4px 0px #000000, 0 4px 15px rgba(255, 71, 87, 0.4)";
        } else {
            banner.style.borderColor = "#000000"; titleEl.style.color = "#000000";
            banner.style.boxShadow = "4px 4px 0px #000000";
        }
    }

    const btn = document.getElementById('end-phase-btn');
    if (btnText) { btn.style.display = 'inline-block'; btn.innerText = btnText; }
    else btn.style.display = 'none';
}

function triggerCinematic(type, params = null) {
    cinematics.active = true;
    cinematics.time = 0;
    cinematics.type = type;
    cinematics.params = params;
    cinematics.startPos.copy(camera.position);
    document.getElementById('ui-layer').classList.add('hidden');
}

function endCinematic() {
    cinematics.active = false;
    document.getElementById('ui-layer').classList.remove('hidden');
}

function triggerCinematicPhaseText(text, color) {
    const overlay = document.getElementById('cinematic-phase-overlay');
    const textEl = document.getElementById('cinematic-phase-text');
    if (overlay && textEl) {
        textEl.innerText = text; textEl.style.color = color;
        overlay.classList.remove('hidden'); overlay.style.display = 'block';
        textEl.classList.remove('cinematic-pop');
        void textEl.offsetWidth; 
        textEl.classList.add('cinematic-pop');
        setTimeout(() => { overlay.classList.add('hidden'); overlay.style.display = 'none'; }, 1800);
    }
}

var runCinematic = function(dt) {
    if (!cinematics.active) return;
    cinematics.time += dt;
    // Simple basic slow orbit or pan based on cinematic type
    const t = cinematics.time;
    
    if (cinematics.type === 'intro') {
        camera.position.x = Math.sin(t * 0.5) * 30;
        camera.position.z = Math.cos(t * 0.5) * 30;
        camera.position.y = 15;
        camera.lookAt(0, 0, 0);
        if (t > 4) endCinematic();
        
    } else if (cinematics.type === 'combat_intro') {
        camera.position.x = cinematics.startPos.x + Math.sin(t) * 5;
        camera.position.y = cinematics.startPos.y - t * 2;
        camera.position.z = cinematics.startPos.z - t * 2;
        camera.lookAt(0, 0, 0);
        if (t > 2) endCinematic();
        
    } else if (cinematics.type === 'base_destroyed') {
        const px = cinematics.params?.x || 0;
        const pz = cinematics.params?.z || 0;
        camera.position.x = px + Math.sin(t) * 15;
        camera.position.z = pz + Math.cos(t) * 15;
        camera.position.y = 10;
        camera.lookAt(px, 0, pz);
        if (t > 3) endCinematic();
        
    } else if (cinematics.type === 'victory' || cinematics.type === 'defeat') {
        camera.position.x = Math.sin(t * 0.5) * 40;
        camera.position.z = Math.cos(t * 0.5) * 40;
        camera.position.y = 20;
        camera.lookAt(0, 0, 0);
        if (t > 5) {
            endCinematic();
        }
    } else {
        if (t > 2) endCinematic();
    }
};
