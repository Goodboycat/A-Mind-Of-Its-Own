// ===========================================================
// MEDIEVAL COMMANDER ROSTER
// Personality types preserved: loyal / coward / violent / machine
// "machine" reflavored as "disciplined" (war-machines & drilled regulars)
// ===========================================================
const UNIT_TYPES = [
    // --- Loyal Knights & Order ---
    { id: 1,  name: "King's Knight",     icon: "⚔️", type: "loyal",       hp: 110, atk: 16, loyalty: 85, speed: 2.0, color: "#feca57", role: "infantry",  cost: 8  },
    { id: 2,  name: "Holy Templar",      icon: "✝️", type: "loyal",       hp: 130, atk: 14, loyalty: 95, speed: 1.7, color: "#fff5d6", role: "infantry",  cost: 9  },
    { id: 3,  name: "Royal Paladin",     icon: "🛡️", type: "loyal",       hp: 170, atk: 12, loyalty: 90, speed: 1.5, color: "#ff9f43", role: "tank",      cost: 12 },
    { id: 4,  name: "Battle Monk",       icon: "📿", type: "loyal",       hp: 80,  atk: 10, loyalty: 88, speed: 2.0, color: "#c8d6e5", role: "support",   cost: 5  },

    // --- Coward / Untrained Levy ---
    { id: 5,  name: "Peasant Levy",      icon: "🌾", type: "coward",      hp: 45,  atk: 5,  loyalty: 25, speed: 3.2, color: "#dcc78a", role: "skirmish",  cost: 2  },
    { id: 6,  name: "Scared Squire",     icon: "🐣", type: "coward",      hp: 55,  atk: 6,  loyalty: 30, speed: 3.4, color: "#48dbfb", role: "skirmish",  cost: 3  },
    { id: 7,  name: "Deserter",          icon: "🏃", type: "coward",      hp: 60,  atk: 12, loyalty: 20, speed: 3.8, color: "#ff6b6b", role: "skirmish",  cost: 4  },

    // --- Violent / Mercenary / Berserker ---
    { id: 8,  name: "Mad Berserker",     icon: "🪓", type: "violent",     hp: 95,  atk: 26, loyalty: 25, speed: 2.6, color: "#ee5253", role: "infantry",  cost: 9  },
    { id: 9,  name: "Sellsword",         icon: "🗡️", type: "violent",     hp: 85,  atk: 20, loyalty: 35, speed: 2.4, color: "#341f97", role: "infantry",  cost: 7  },
    { id: 10, name: "Highland Reaver",   icon: "🐗", type: "violent",     hp: 140, atk: 18, loyalty: 25, speed: 1.9, color: "#1dd1a1", role: "tank",      cost: 10 },

    // --- Machine / Disciplined Regulars & War-Engines ---
    { id: 11, name: "Pike Phalanx",      icon: "🔱", type: "machine",     hp: 140, atk: 11, loyalty: 100, speed: 1.5, color: "#8395a7", role: "tank",     cost: 9  },
    { id: 12, name: "Crossbow Regular",  icon: "🏹", type: "machine",     hp: 75,  atk: 18, loyalty: 100, speed: 1.6, color: "#c8d6e5", role: "ranged",   cost: 8  },
    { id: 13, name: "Battering Ram",     icon: "🪵", type: "machine",     hp: 220, atk: 8,  loyalty: 100, speed: 1.1, color: "#8b5a2b", role: "siege",    cost: 14 },
    { id: 14, name: "Royal Captain",     icon: "🎖️", type: "machine",     hp: 120, atk: 17, loyalty: 100, speed: 1.9, color: "#ffd6a5", role: "infantry", cost: 11 }
];

// Quick lookup for rendering & balance
const UNIT_BY_ID = {};
UNIT_TYPES.forEach(u => UNIT_BY_ID[u.id] = u);

// Personality flavor lines — used in speech bubbles & event log
const PERSONALITY_LINES = {
    loyal:   { obey: ["For the crown!", "By your order!", "Aye, commander!"], disobey: [],
               attack: ["For honor!", "Hold the line!", "On me!"],
               retreat: ["Falling back, sire!", "Regroup at the keep!"],
               defend:  ["To the wall!", "Shields up!"],
               praise:  ["Thank you, my lord!", "I'll not fail you!", "Bless you, commander!"],
               mine:  ["Mining for the realm!", "Gems for the king!"] },
    coward:  { obey: ["...I-if I must.", "Don't leave me!"],
               disobey: ["I won't die for this!", "Sound the retreat!", "Mama..."],
               attack: ["Please don't hurt me!", "Just one swing!"],
               retreat: ["Yes! Run!", "Finally! RUN!", "Saving my skin!"],
               defend:  ["M-must I?", "I'll try to hold..."],
               praise:  ["Y-you mean it?", "...I feel braver!", "Maybe I won't run..."],
               mine:  ["...gems are heavy.", "Hurry, hurry!"] },
    violent: { obey: ["...Fine.", "Whatever."],
               disobey: ["OUT OF MY WAY!", "I'll kill ANYONE!", "BLOOD!"],
               attack: ["RIP AND TEAR!", "DIE!", "FOR ME!"],
               retreat: ["COWARDS!", "Tch. Fine.", "This isn't over."],
               defend:  ["Come get some!", "I'll guard. For now."],
               praise:  ["Heh. About time.", "Don't get soft.", "...alright."],
               mine:  ["Stupid rocks!", "Ugh, labor."] },
    machine: { obey: ["Order confirmed.", "Advancing.", "Formation.", "As ordered, sir."],
               disobey: [],
               attack: ["Engaging.", "Target acquired.", "Strike!"],
               retreat: ["Withdrawing.", "Tactical fallback."],
               defend:  ["Defensive formation.", "Holding line."],
               praise:  ["Morale: +1.", "Acknowledged.", "Loyalty reinforced."],
               mine:  ["Extraction protocol.", "Resource acquired."] }
};

var playerInventory = [];
var gems = 80;          // (was 50)  — softer opening so first deploys aren't a coin flip
var enemyGems = 70;   // (was 55) keeps AI competitive against rebalanced costs
var nextEntityId = 1;

// --- GEM ECONOMY GLOBALS ---
// Capacity each unit can carry per trip
const UNIT_CARRY_CAPACITY = 3;
// How long mining a single chunk takes (seconds)
const MINING_DURATION = 1.4;   // (was 1.8) — mining now feels less punishing
// Refined gems earned per delivered chunk
const REFINED_PER_CHUNK = 7;   // (was 4)   — 3 chunks * 7 = 21 gems per delivery, vs. ~5–6 cost units
// Recruit cost (was 10) — see ui.js pullGacha
const RECRUIT_COST = 7;
// Active deposits & dropped piles
var gemDeposits = [];     // { x, z, remaining, mesh, sparkleSprite }
var droppedGems = [];     // { x, z, amount, mesh, isPlayer (owner that mined it), age }

function generateUnit() {
    const template = UNIT_TYPES[Math.floor(Math.random() * UNIT_TYPES.length)];
    return { ...template, uid: nextEntityId++, currentHp: template.hp, maxHp: template.hp };
}
window.generateUnit = generateUnit;

function pickPersonalityLine(type, mood) {
    const pool = (PERSONALITY_LINES[type] && PERSONALITY_LINES[type][mood]) || [];
    if (!pool.length) return null;
    return pool[Math.floor(Math.random() * pool.length)];
}
window.pickPersonalityLine = pickPersonalityLine;

// ===========================================================
// UNIT ASSET MAPPING
// Each unit name is normalised (alphanumeric, lowercase) and
// mapped to a PascalCase PNG in /assets. If the PNG is missing
// or broken, getUnitIconHtml renders the emoji as a fallback
// (via the <img>'s onerror handler).
//
// REQUIRED PNGS (place in /assets):
//   KingsKnight.png     HolyTemplar.png      RoyalPaladin.png
//   BattleMonk.png      PeasantLevy.png      ScaredSquire.png
//   Deserter.png        MadBerserker.png     Sellsword.png
//   HighlandReaver.png  PikePhalanx.png      CrossbowRegular.png
//   BatteringRam.png    RoyalCaptain.png
// ===========================================================
function getUnitAssetUrl(name) {
    if (!name) return null;
    const cleanName = name.replace(/[^A-Za-z0-9]/g, '');
    if (!cleanName) return null;

    // 1) If a runtime ASSETS_DATA map exists (e.g. embedded data: URLs), prefer it.
    let assetsData = window._assetsDataCached || window.ASSETS_DATA;
    if (!assetsData) {
        try {
            if (window.parent && window.parent.ASSETS_DATA) {
                assetsData = window.parent.ASSETS_DATA;
            }
        } catch (e) { /* cross-origin: ignore */ }
    }
    if (assetsData) {
        window._assetsDataCached = assetsData;
        const keys = Object.keys(assetsData);
        const lcClean = cleanName.toLowerCase();
        for (const k of keys) {
            const cleanKey = k.toLowerCase().split('/').pop().replace('.png', '').replace(/[^a-z0-9]/g, '');
            if (cleanKey === lcClean) return assetsData[k];
        }
        for (const k of keys) {
            if (!k.endsWith('.png') || k.toLowerCase().includes('start') || k.toLowerCase().includes('grass')) continue;
            const cleanKey = k.toLowerCase().split('/').pop().replace('.png', '').replace(/[^a-z0-9]/g, '');
            if (lcClean.includes(cleanKey) || cleanKey.includes(lcClean)) return assetsData[k];
        }
    }

    // 2) Default: try the canonical PascalCase file on disk.
    //    If the file is missing the <img onerror> will hide it and the emoji span will remain.
    return 'assets/' + cleanName + '.png';
}
window.getUnitAssetUrl = getUnitAssetUrl;

// Renders an icon for a unit using a PNG sprite (if present) with the emoji as fallback.
// The <img> sits in front of the emoji span; on successful load, it hides the emoji.
// On error (missing/broken file), the <img> is hidden and the emoji remains visible.
function getUnitIconHtml(u, customSize) {
    if (!u) return '';
    const url = getUnitAssetUrl(u.name);
    const sz  = customSize || '26px';
    const emoji = u.icon || '';
    if (!url) return '<span class="unit-emoji-fallback">' + emoji + '</span>';
    // The img is overlaid above the emoji via CSS. onload hides the emoji; onerror hides the img.
    return '<span class="unit-icon-wrap" style="display:inline-flex;align-items:center;justify-content:center;width:' + sz + ';height:' + sz + ';position:relative;line-height:1;">' +
               '<span class="unit-emoji-fallback" style="font-size:' + sz + ';line-height:1;">' + emoji + '</span>' +
               '<img src="' + url + '" class="card-icon-img" ' +
                    'style="position:absolute;top:0;left:0;width:' + sz + ';height:' + sz + ';object-fit:contain;image-rendering:pixelated;" ' +
                    'onload="var s=this.previousElementSibling; if(s)s.style.display=\'none\';" ' +
                    'onerror="this.style.display=\'none\'; var s=this.previousElementSibling; if(s)s.style.display=\'inline-block\';" />' +
           '</span>';
}
window.getUnitIconHtml = getUnitIconHtml;
