// ===========================================================
// MAIN — start logic, render loop, board click routing
// ===========================================================

// ===========================================================
// ARENA LIMITS — invisible border so units can't run infinitely
// off the terrain. World coords are [-MAP_SIZE/2, +MAP_SIZE/2];
// we leave a 2-unit safety margin from the visible edge.
// ===========================================================
const ARENA_LIMIT = MAP_SIZE / 2 - 2; // = 58 when MAP_SIZE=120
function clampToArena(v) {
    if (v >  ARENA_LIMIT) return  ARENA_LIMIT;
    if (v < -ARENA_LIMIT) return -ARENA_LIMIT;
    return v;
}
window.ARENA_LIMIT = ARENA_LIMIT;
window.clampToArena = clampToArena;

function startGame() {
    document.getElementById('world-ui').classList.add('hidden');
    document.getElementById('battle-ui').classList.remove('hidden');
    document.getElementById('phase-banner').classList.remove('hidden');
    // Reveal the surrender button now that we're in battle
    const giveBtn = document.getElementById('giveup-btn');
    if (giveBtn) giveBtn.classList.remove('hidden');

    // ===== FIELD ROSTER: force-open on game start so new users see it =====
    const cpContainer = document.getElementById('commander-panel-container');
    cpContainer.classList.remove('hidden');
    cpContainer.classList.remove('collapsed');
    const cpBtn = document.getElementById('commander-toggle-btn');
    if (cpBtn) {
        cpBtn.innerText = '◀';
        cpBtn.classList.remove('collapsed-btn');
    }
    if (typeof window !== 'undefined') window.commanderPanelHidden = false;
    // Brief attention-pulse so new players notice it
    cpContainer.classList.add('roster-attention');
    setTimeout(() => cpContainer.classList.remove('roster-attention'), 4200);

    document.getElementById('base-hud').classList.remove('hidden');

    if (window.SFX) SFX.play('prepStart');
    gameState = 'battle';
    battlePhase = 'prep';
    setPhaseText("PREP PHASE", "Deploy units in your half. Then begin the assault.", "Begin Assault (10s)");

    // ---------- Spawn BASES ----------
    // Fair match: ONE player keep, ONE AI keep. No pre-spawned units on the field.
    spawnBase(0,  38, true,  1.1, 500);
    spawnBase(0, -42, false, 1.1, 500);

    // ---------- Spawn GEM DEPOSITS ----------
    spawnInitialGemDeposits();

    // NOTE: AI starts with NO units on the battlefield. Its first deployment
    // happens in endPrepPhase() and mirrors the player's starter roster
    // (one of each personality type), keeping the opening symmetric.
    window._aiFirstDeploy = true;

    logEvent("⚑ Battle begins — defend your keep!", '#ffd166');
    logEvent("⛏️ Gem deposits glimmer on the field — send a unit to mine!", '#5fdfff');
    renderDeployedRoster();
    renderBaseHUD();
    triggerCinematic('intro', {});
}

function endPrepPhase() {
    setPhaseText("ENEMY PREP", "AI is issuing orders…", null);
    battlePhase = 'enemy_prep';
    selectedInvIndex = -1; renderInventory();

    // ---------- SMART ENEMY AI LOGIC ----------
    let activeBases = enemyBases.filter(b => !b.destroyed);
    if (activeBases.length > 0) {
        let spawnedCount = 0;

        // FIRST prep phase — mirror the player's starter roster (one of each personality type).
        // This keeps the opening symmetric instead of random RNG.
        if (window._aiFirstDeploy) {
            const STARTER_IDS = [1, 5, 9, 11]; // King's Knight, Peasant Levy, Sellsword, Pike Phalanx
            const base = activeBases[0];
            STARTER_IDS.forEach((id, i) => {
                const tp = UNIT_BY_ID[id]; if (!tp) return;
                const angle = (i / STARTER_IDS.length) * Math.PI * 2;
                const ex = base.x + Math.cos(angle) * 4;
                const ez = base.z + 4 + Math.sin(angle) * 2;
                spawnUnitOnBoard({ ...tp, currentHp: tp.hp, maxHp: tp.hp }, ex, ez, false);
                spawnedCount++;
            });
            window._aiFirstDeploy = false;
        } else {
            // Subsequent prep phases — buy reinforcements with the AI's gem budget.
            let protectionCycles = 0;
            while (enemyGems >= 10 && spawnedCount < 4 && protectionCycles++ < 50) {
                const pool = [8, 9, 10, 11, 12, 14]; // viable templates
                let id = pool[Math.floor(Math.random() * pool.length)];
                let tp = UNIT_BY_ID[id];
                if (!tp) tp = UNIT_TYPES[Math.floor(Math.random() * UNIT_TYPES.length)];
                let cost = tp.cost || 10;
                if (enemyGems < cost) break;

                let base = activeBases[Math.floor(Math.random() * activeBases.length)];
                let ex = base.x + (Math.random() - 0.5) * 8;
                let ez = base.z + 3 + Math.random() * 5;

                spawnUnitOnBoard({ ...tp, currentHp: tp.hp, maxHp: tp.hp }, ex, ez, false);
                enemyGems -= cost;
                spawnedCount++;
            }
        }
        if (spawnedCount > 0) {
            logEvent(`⚔️ AI deployed ${spawnedCount} reinforcements near their keep!`, '#ff4757');
        }
    }

    // AI strategically divides its forces on combat entry
    let myUnits = entities.filter(e => !e.isPlayer && e.data && e.data.currentHp > 0);
    let mineQuota = Math.max(1, Math.floor(myUnits.length * 0.35));
    // If extremely low on gems, assign more units to mine to fund survival
    if (enemyGems < 20) {
        mineQuota = Math.max(1, Math.floor(myUnits.length * 0.65));
    }

    myUnits.forEach((e, idx) => {
        if (idx < mineQuota) {
            e.order = 'mine';
            e.orderTarget = null;
            if (window.setEntityOrderIcon) setEntityOrderIcon(e);
        } else {
            e.order = 'attack';
            e.orderTarget = null;
        }
    });

    setTimeout(() => {
        battlePhase = 'combat';
        combatTimer = 12.0;
        setPhaseText("COMBAT PHASE", "12.0 seconds remaining", null);
        triggerCinematic('combat_intro', {});
        if (window.SFX) SFX.play('combatStart');
    }, 1400);
}

function pingLocation() {
    // Arm rally mode — next tap on the map drops a rally beacon AT THE TAP POINT.
    latestEmoji = '📍';
    commandMode = null;
    showScreenToast('📍 Tap the map to drop a rally beacon', 'default');
    if (window.SFX) SFX.play('rally');
}
window.pingLocation = pingLocation;

function sendEmoji(e) {
    if (e === '📍') return;

    // Each global command now ACTUALLY issues orders to all loyal player units
    // instead of just setting an ambient flag the units may ignore.
    if (e === '⛏️') { if (window.SFX) SFX.play('click'); issueAllMine();    return; }
    if (e === '⚔️') { if (window.SFX) SFX.play('combatStart'); issueAllAttack();  return; }
    if (e === '🛡️') { if (window.SFX) SFX.play('click'); issueAllDefend();  return; }
    if (e === '🏃') { if (window.SFX) SFX.play('retreat'); issueAllRetreat(); return; }
    if (e === '💖') { if (window.SFX) SFX.play('praise'); issueAllPraise();  return; }

    // Fallback (shouldn't hit) — brief screen toast, no world text
    latestEmoji = e;
    showScreenToast(e + ' Order', 'default');
    setTimeout(() => latestEmoji = null, 3000);
}
window.sendEmoji = sendEmoji;

function onBoardClick(e) {
    mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObject(terrainMesh);
    if (intersects.length === 0) return;
    const p = intersects[0].point;
    const gx = Math.floor(p.x + MAP_SIZE / 2);
    const gz = Math.floor(p.z + MAP_SIZE / 2);
    const isValidDrop = (gx >= 0 && gx < MAP_SIZE && gz >= 0 && gz < MAP_SIZE && (mapGrid[gx][gz] === 0 || mapGrid[gx][gz] === 3));

    // 1) Per-unit order map-tap
    if (gameState === 'battle' && selectedUnitIndex >= 0 && commandMode) {
        const ent = entities[selectedUnitIndex];
        if (ent && ent.isPlayer) {
            ent.order = commandMode;
            ent.orderTarget = { x: p.x, z: p.z };
            ent.miningPhase = null;
            setEntityOrderIcon(ent);
            const map = { attack: '⚔️', ping: '📍', hold: '🚩' };
            triggerFloatingText(map[commandMode] || '✔', p.x, 2.5, p.z, '#ffd166');
            const line = pickPersonalityLine(ent.data.type, 'obey');
            if (line) triggerSpeechBubble(line, ent.px, 5.0, ent.pz, 'attacker', ent);
            logEvent(`${ent.data.icon} ${ent.data.name} → ${commandMode}`, '#0abde3');
            commandMode = null;
            renderOrderPanel();
            renderDeployedRoster();
            return;
        }
    }

    // 2) Deployment during prep
    if (gameState === 'battle' && battlePhase === 'prep' && selectedInvIndex >= 0) {
        if (p.z > 5 && isValidDrop) {
            const unit = playerInventory[selectedInvIndex];
            if (gems < (unit.cost || 0)) {
                showScreenToast(`Need ${unit.cost} 💎 to deploy`, 'error');
                return;
            }
            gems -= (unit.cost || 0);
            document.getElementById('gem-count').innerText = gems;
            spawnUnitOnBoard(unit, p.x, p.z, true);
            playerInventory.splice(selectedInvIndex, 1);
            selectedInvIndex = -1;
            renderInventory();
            renderDeployedRoster();
            logEvent(`🛡️ Deployed ${unit.icon} ${unit.name}`, '#7bed9f');
            if (window.SFX) SFX.play('deploy');
        } else if (!isValidDrop) {
            showScreenToast('Invalid terrain', 'error');
            if (window.SFX) SFX.play('error');
        } else {
            showScreenToast('Deploy on your side of the field', 'error');
            if (window.SFX) SFX.play('error');
        }
        return;
    }

    // 3) Select a deployed unit by tapping near it
    if (gameState === 'battle') {
        let bestIdx = -1, bestD = 1.6;
        for (let i = 0; i < entities.length; i++) {
            const en = entities[i];
            if (!en.isPlayer || en.data.currentHp <= 0) continue;
            const d = Math.hypot(en.px - p.x, en.pz - p.z);
            if (d < bestD) { bestD = d; bestIdx = i; }
        }
        if (bestIdx >= 0) { selectDeployedUnit(bestIdx); return; }
        if (selectedUnitIndex >= 0 && !commandMode) { deselectUnit(); }
    }

    // 4) Broadcast ping
    if (gameState === 'battle' && latestEmoji === '📍') {
        currentPing = { x: p.x, z: p.z };
        triggerFloatingText("📍 RALLY", p.x, 2, p.z, '#ff9f43');
        latestEmoji = null;
    }
}

function animate() {
    requestAnimationFrame(animate);
    let dt = Math.min(clock.getDelta(), 0.1);

    // PC input (keyboard pan, Q/E zoom, zoom smoothing). Runs every frame so
    // held keys feel responsive. Touch & mouse drag are still pointer-driven.
    if (window.tickInput) window.tickInput(dt);

    if (slowMo.time > 0) { slowMo.time -= dt; dt *= slowMo.factor; }
    else slowMo.factor = 1.0;

    if (cinematicOverlay) cinematicOverlay.material.uniforms.time.value += dt;

    let uCine = cinematics.active ? 1.0 : 0.0;
    uCinematicLerp += (uCine - uCinematicLerp) * 0.08;
    if (typeof updateShaderUniforms === 'function') {
        updateShaderUniforms(scene, camera, clock.elapsedTime, uCinematicLerp);
    }
    if (terrainMat && terrainMat.uniforms && terrainMat.uniforms.uCinematic) {
        terrainMat.uniforms.uCinematic.value = uCinematicLerp;
    }

    if (cinematics.active) {
        cinematics.time += dt;
        runCinematic(dt);
    } else {
        camera.position.lerp(targetCameraPos, 0.1);
        let shakeX = 0, shakeY = 0;
        if (cameraShake.time > 0) {
            cameraShake.time -= dt;
            shakeX = (Math.random() - 0.5) * cameraShake.magnitude * 2;
            shakeY = (Math.random() - 0.5) * cameraShake.magnitude * 2;
            if (cameraShake.time <= 0) cameraShake.magnitude = 0;
        }
        camera.position.x += shakeX;
        camera.position.y += shakeY;
        camera.lookAt(camera.position.x, 0, camera.position.z - 15);
        cinematicOverlay.material.uniforms.intensity.value = Math.max(0, cinematicOverlay.material.uniforms.intensity.value - dt * 2.0);
    }

    if (gameState === 'battle') {
        if (!cinematics.active && battlePhase === 'combat' && !matchResult) {
            combatTimer -= dt;
            const sub = document.getElementById('phase-sub');
            if (sub) sub.innerText = combatTimer.toFixed(1) + " seconds remaining";
            updateEntities(dt);
            if (window.updateProjectiles) updateProjectiles(dt);
            updateBases(dt);
            updateGemDeposits(dt);
            updateDroppedGems(dt);
            renderBaseHUD();
            if (combatTimer <= 0) {
                battlePhase = 'prep';
                setPhaseText("PREP PHASE", "Reinforce your line. Then continue the assault.", "Continue Assault (12s)");
                entities.forEach(e => { e.state = 'idle'; e.kbX = 0; e.kbZ = 0; e.attackTarget = null; });
            }
        } else {
            // Animate visuals outside combat (no entity AI during prep)
            updateBases(dt);
            updateGemDeposits(dt);
            updateDroppedGems(dt);
            renderBaseHUD();
        }
    }

    updateFloatingTexts(dt);
    updateLivelyEmojis(dt);
    renderer.render(scene, camera);
}

// ===========================================================
// GIVE-UP / SURRENDER
// ===========================================================
function giveUpBattle() {
    // Only meaningful while in an active battle that hasn't ended yet
    if (gameState !== 'battle' || matchResult) return;
    const modal = document.getElementById('giveup-modal');
    if (modal) modal.classList.remove('hidden');
    if (window.SFX) SFX.play('click');
}
function cancelGiveUp() {
    const modal = document.getElementById('giveup-modal');
    if (modal) modal.classList.add('hidden');
    if (window.SFX) SFX.play('click');
}
function confirmGiveUp() {
    const modal = document.getElementById('giveup-modal');
    if (modal) modal.classList.add('hidden');
    if (gameState !== 'battle' || matchResult) return;

    // Force defeat: collapse the player's keep, then route through normal end-screen flow.
    matchResult = 'defeat';
    if (window.logEvent) logEvent("🏳️ You have surrendered the field.", '#ff4757');
    if (typeof playerBase !== 'undefined' && playerBase && !playerBase.destroyed) {
        // Use damageBase so the death animation/cinematic plays, but skip the
        // delayed checkVictoryCondition by setting matchResult first (above).
        try {
            if (window.damageBase) damageBase(playerBase, playerBase.currentHp + 9999, null);
        } catch (e) { /* defensive: fall through to direct end-screen */ }
    }
    // Hide the surrender button so it can't be re-triggered
    const giveBtn = document.getElementById('giveup-btn');
    if (giveBtn) giveBtn.classList.add('hidden');

    // Trigger defeat cinematic + end screen (mirrors checkVictoryCondition path)
    if (window.triggerCinematic) triggerCinematic('defeat', {});
    setTimeout(() => { if (window.showEndScreen) showEndScreen('defeat'); }, 2500);
}
window.giveUpBattle = giveUpBattle;
window.cancelGiveUp  = cancelGiveUp;
window.confirmGiveUp = confirmGiveUp;

window.onload = init;
