let scene, camera, renderer, clock;
const MAP_SIZE = 120;
const mapGrid = [];
const heightMap = [];
let terrainGeo, terrainMat, terrainMesh;

const entities = [];
const floatingTexts = [];
const livelyEmojis = [];

var bases = [];
var enemyBases = [];
var playerBase = null;
var selectedInvIndex = -1;
var selectedUnitIndex = -1;
var commandMode = null;
var eventLog = [];
var slowMo = { time: 0, factor: 1.0 };
var cameraShake = { time: 0, magnitude: 0.0 };
var uCinematicLerp = 0.0;
var matchResult = null;
var shakeCamera = function(time, magnitude) {
    cameraShake.time = time;
    cameraShake.magnitude = magnitude;
};
var triggerSlowMo = function(factor, time) {
    slowMo.factor = factor;
    slowMo.time = time;
};
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

let gameState = 'world'; 


let battlePhase = 'prep'; 
let combatTimer = 0; 


let isDragging = false;
let cameraClickValid = false;
let dragStartX = 0, dragStartY = 0;
const targetCameraPos = new THREE.Vector3(0, 24, 25);
const camStartPos = new THREE.Vector3();

// --- ZOOM (PC mouse wheel + mobile pinch) ----------------------------------
// We model zoom as a scalar in [ZOOM_MIN .. ZOOM_MAX] that multiplies the
// camera's resting height & look-back distance. 1.0 = default framing.
const ZOOM_MIN = 0.55;   // closer
const ZOOM_MAX = 1.85;   // farther
let zoomLevel = 1.0;
let targetZoom = 1.0;
const BASE_CAM_Y = 24;       // matches initial targetCameraPos.y = 24

// --- PINCH (multi-touch) ---------------------------------------------------
const activePointers = new Map();   // pointerId -> {x,y}
let pinchStartDist = 0;
let pinchStartZoom = 1.0;
let isPinching = false;

// --- KEYBOARD PAN ----------------------------------------------------------
const keysDown = Object.create(null);

const cinematics = {
    active: false,
    time: 0,
    type: 'intro', 
    params: null,
    startPos: new THREE.Vector3()
};
let cinematicOverlay;

let currentPing = null;
let latestEmoji = null;

function init() {
    setupThree();
    setupWorld();
    
    // Setup initial roster — fair & deterministic: one of each PERSONALITY type
    // (loyal / coward / violent / machine) instead of random pulls.
    // Same roster is mirrored to the AI in endPrepPhase() for the very first deploy.
    const STARTER_IDS = [1, 5, 9, 11]; // King's Knight, Peasant Levy, Sellsword, Pike Phalanx
    STARTER_IDS.forEach(id => {
        const tp = UNIT_BY_ID[id];
        if (tp) playerInventory.push({ ...tp, uid: nextEntityId++, currentHp: tp.hp, maxHp: tp.hp });
    });
    renderInventory();
    
    window.addEventListener('resize', () => {
        if (camera && renderer) {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }
    });

    requestAnimationFrame(animate);
    
    // Bind globals for HTML
    window.startGame = startGame;
    window.endPrepPhase = endPrepPhase;
    window.pingLocation = pingLocation;
    window.sendEmoji = sendEmoji;
    window.pullGacha = pullGacha;
}

function setupThree() {
    const canvas = document.getElementById('game-canvas');
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    renderer.setSize(window.innerWidth || 800, window.innerHeight || 600);
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    
    scene = new THREE.Scene();
    scene.background = new THREE.Color('#1e272e');
    scene.fog = new THREE.FogExp2('#1e272e', 0.022);
    
    camera = new THREE.PerspectiveCamera(55, window.innerWidth/window.innerHeight, 0.1, 150);
    
    // Shader for cinematics making them even more movie like (Letterbox + Grain + Vignette)
    cinematicOverlay = new THREE.Mesh(
        new THREE.PlaneGeometry(2, 2),
        new THREE.ShaderMaterial({
            transparent: true,
            uniforms: {
               time: { value: 0 },
               intensity: { value: 0.0 }
            },
            vertexShader: `
               varying vec2 vUv;
               void main() {
                   vUv = uv;
                   gl_Position = vec4(position, 1.0);
               }
            `,
            fragmentShader: `
               uniform float time;
               uniform float intensity;
               varying vec2 vUv;
               float rand(vec2 co){ return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453); }
               void main() {
                   float grain = rand(vUv * time) * 0.15 * intensity;
                   float dist = distance(vUv, vec2(0.5));
                   float vignette = smoothstep(0.8, 0.2, dist) * 0.4 + 0.6;
                   vignette = mix(1.0, vignette, intensity);
                   
                   float letterbox = 1.0;
                   if (vUv.y < 0.12 * intensity || vUv.y > 1.0 - 0.12 * intensity) letterbox = 0.0;
                   
                   gl_FragColor = vec4(0.05, 0.05, 0.05, 1.0 - (vignette * letterbox) + grain);
                   if (letterbox == 0.0) gl_FragColor = vec4(0.0, 0.0, 0.0, intensity);
               }
            `,
            depthTest: false,
            depthWrite: false
        })
    );
    // Attach overlay to camera
    camera.add(cinematicOverlay);
    scene.add(camera);
    
    clock = new THREE.Clock();
    
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);
    const dirLight = new THREE.DirectionalLight(0xdff9fb, 0.8);
    dirLight.position.set(5,10,5); 
    scene.add(dirLight);

    setupMap();
    setupCameraControls();
}

function setupCameraControls() {
    const dom = renderer.domElement;

    // Suppress the browser context menu on right-click so we can use it as
    // an in-game "cancel / deselect" gesture (RTS convention).
    dom.addEventListener('contextmenu', e => e.preventDefault());

    dom.addEventListener('pointerdown', e => {
        // Track every active pointer (needed for pinch).
        activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

        // Right-click (button === 2) on PC = cancel/deselect, do not drag.
        if (e.button === 2) {
            if (typeof cancelSelectionOrCommand === 'function') cancelSelectionOrCommand();
            isDragging = false; cameraClickValid = false;
            return;
        }

        // If two fingers are now down, switch to pinch mode and abort drag.
        if (activePointers.size === 2) {
            const pts = Array.from(activePointers.values());
            pinchStartDist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
            pinchStartZoom = targetZoom;
            isPinching = true;
            isDragging = false;
            cameraClickValid = false;
            return;
        }

        isDragging = true; cameraClickValid = true;
        dragStartX = e.clientX; dragStartY = e.clientY;
        camStartPos.copy(targetCameraPos);
    });

    dom.addEventListener('pointermove', e => {
        if (activePointers.has(e.pointerId)) {
            activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
        }

        // Pinch-zoom (two pointers) takes priority over drag.
        if (isPinching && activePointers.size >= 2) {
            const pts = Array.from(activePointers.values());
            const d = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
            if (pinchStartDist > 0) {
                const ratio = pinchStartDist / d; // farther fingers = zoom in (smaller value)
                targetZoom = clampZoom(pinchStartZoom * ratio);
            }
            return;
        }

        if (isDragging) {
            let dx = e.clientX - dragStartX; let dy = e.clientY - dragStartY;
            if (Math.hypot(dx, dy) > 5) cameraClickValid = false;
            // Pan speed scales with zoom so the world feels consistent at any framing.
            const panScale = 0.05 * zoomLevel;
            targetCameraPos.x = camStartPos.x - dx * panScale;
            targetCameraPos.z = camStartPos.z - dy * panScale;
        }
    });

    dom.addEventListener('pointerup', e => {
        const wasPinching = isPinching;
        activePointers.delete(e.pointerId);
        if (activePointers.size < 2) isPinching = false;

        // Skip click-routing if we just finished a pinch or it was a right-click.
        if (wasPinching || e.button === 2) { isDragging = false; return; }

        isDragging = false;
        if (cameraClickValid) onBoardClick(e);
    });

    dom.addEventListener('pointerleave', e => {
        activePointers.delete(e.pointerId);
        if (activePointers.size < 2) isPinching = false;
        isDragging = false;
    });
    dom.addEventListener('pointercancel', e => {
        activePointers.delete(e.pointerId);
        if (activePointers.size < 2) isPinching = false;
        isDragging = false;
    });

    // ---------- MOUSE WHEEL ZOOM (PC) ----------
    dom.addEventListener('wheel', e => {
        e.preventDefault();
        // deltaY > 0 = scroll down = zoom out
        const step = (e.deltaY > 0 ? 1 : -1) * 0.12;
        targetZoom = clampZoom(targetZoom + step);
    }, { passive: false });

    // ---------- KEYBOARD ----------
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup',   onKeyUp);
}

function clampZoom(z) {
    if (z < ZOOM_MIN) return ZOOM_MIN;
    if (z > ZOOM_MAX) return ZOOM_MAX;
    return z;
}

// ---------------------------------------------------------------------------
// KEYBOARD HANDLING
//   Movement: WASD / Arrow keys (continuous, applied each frame)
//   Zoom:     Q / E (continuous), or mouse wheel
//   Commands: number row hotbar 1..5, Space = Rally, Enter = Begin Assault
//   Misc:     Esc = cancel/close, H = hide UI
//
// Using the number row for command shortcuts (instead of A/F/M/R/P) avoids
// any conflict with WASD pan — a held movement key never spams an order.
// ---------------------------------------------------------------------------
function onKeyDown(e) {
    // Ignore typing into text inputs (none today, but future-proof)
    const t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;

    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    keysDown[k] = true;

    // Discrete (press-once) actions
    switch (k) {
        case 'Escape':
            if (typeof cancelSelectionOrCommand === 'function') cancelSelectionOrCommand();
            e.preventDefault();
            return;
        case 'Enter':
            if (gameState === 'battle' && battlePhase === 'prep' && !cinematics.active) {
                if (window.endPrepPhase) endPrepPhase();
            } else if (gameState === 'world') {
                if (window.startGame) startGame();
            }
            e.preventDefault();
            return;
        case ' ': // Space = Rally
            if (gameState === 'battle' && window.pingLocation) { window.pingLocation(); e.preventDefault(); }
            return;
        case '1':
            if (gameState === 'battle' && window.sendEmoji) { window.sendEmoji('⚔️'); e.preventDefault(); }
            return;
        case '2':
            if (gameState === 'battle' && window.sendEmoji) { window.sendEmoji('🛡️'); e.preventDefault(); }
            return;
        case '3':
            if (gameState === 'battle' && window.sendEmoji) { window.sendEmoji('⛏️'); e.preventDefault(); }
            return;
        case '4':
            if (gameState === 'battle' && window.sendEmoji) { window.sendEmoji('🏃'); e.preventDefault(); }
            return;
        case '5':
            if (gameState === 'battle' && window.sendEmoji) { window.sendEmoji('💖'); e.preventDefault(); }
            return;
        case 'h':
            if (window.toggleUIVisibility) { window.toggleUIVisibility(); e.preventDefault(); }
            return;
    }
}
function onKeyUp(e) {
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    keysDown[k] = false;
}

// Called every frame from animate(): keyboard pan + zoom + apply zoom to camera target.
function tickInput(dt) {
    // Continuous pan via WASD / Arrows
    const panSpeed = 32 * zoomLevel * dt;   // world units / sec
    let dx = 0, dz = 0;
    if (keysDown['w'] || keysDown['ArrowUp'])    dz -= 1;
    if (keysDown['s'] || keysDown['ArrowDown'])  dz += 1;
    if (keysDown['a'] || keysDown['ArrowLeft'])  dx -= 1;
    if (keysDown['d'] || keysDown['ArrowRight']) dx += 1;
    if (dx || dz) {
        const len = Math.hypot(dx, dz) || 1;
        // Clamp to the arena bounds (uses window.clampToArena defined in main.js)
        const cx = targetCameraPos.x + (dx / len) * panSpeed;
        const cz = targetCameraPos.z + (dz / len) * panSpeed;
        targetCameraPos.x = (window.clampToArena ? window.clampToArena(cx) : cx);
        targetCameraPos.z = (window.clampToArena ? window.clampToArena(cz) : cz);
    }

    // Continuous zoom via Q / E
    if (keysDown['q']) targetZoom = clampZoom(targetZoom - 0.9 * dt);
    if (keysDown['e']) targetZoom = clampZoom(targetZoom + 0.9 * dt);

    // Smooth zoom interpolation
    zoomLevel += (targetZoom - zoomLevel) * Math.min(1, dt * 8);

    // Reflect zoom into the camera height & look-back distance.
    // Initial framing (zoom=1) ⇒ y=24, looks at (x, 0, z - 15) per animate().
    targetCameraPos.y = BASE_CAM_Y * zoomLevel;
}
window.tickInput = tickInput;

// Soft-cancel: clear selection, command mode, modals.
function cancelSelectionOrCommand() {
    // Close modals first
    const settings = document.getElementById('settings-modal');
    if (settings && !settings.classList.contains('hidden')) {
        if (window.toggleSettings) window.toggleSettings();
        return;
    }
    const giveModal = document.getElementById('giveup-modal');
    if (giveModal && !giveModal.classList.contains('hidden')) {
        if (window.cancelGiveUp) window.cancelGiveUp();
        return;
    }

    // Clear any armed command + selection
    if (typeof commandMode !== 'undefined' && commandMode) {
        commandMode = null;
        if (window.renderOrderPanel) renderOrderPanel();
    }
    if (typeof selectedInvIndex !== 'undefined' && selectedInvIndex >= 0) {
        selectedInvIndex = -1;
        if (window.renderInventory) renderInventory();
    }
    if (typeof selectedUnitIndex !== 'undefined' && selectedUnitIndex >= 0) {
        if (window.deselectUnit) deselectUnit();
    }
    latestEmoji = null;
}
window.cancelSelectionOrCommand = cancelSelectionOrCommand;

function setupWorld() {
    camera.position.set(0, 20, 15);
    camera.lookAt(0,0,0);
}
