// ===========================================================
// MAP + BASES + GEM DEPOSITS
// =========================================================== */

function noise2D(x, y) {
    let x0 = Math.floor(x); let y0 = Math.floor(y);
    let sx = x - x0; let sy = y - y0;
    let u = sx * sx * (3.0 - 2.0 * sx);
    let v = sy * sy * (3.0 - 2.0 * sy);
    function hash(i, j) {
        let n = Math.sin(i * 12.9898 + j * 78.233) * 43758.5453;
        return n - Math.floor(n);
    }
    let val00 = hash(x0, y0);
    let val10 = hash(x0 + 1, y0);
    let val01 = hash(x0, y0 + 1);
    let val11 = hash(x0 + 1, y0 + 1);
    return val00 + u * (val10 - val00) + v * (val01 - val00 + u * (val11 - val10 - val01 + val00));
}

function setupMap() {
    for (let x = 0; x < MAP_SIZE; x++) {
        mapGrid[x] = [];
        heightMap[x] = [];
        for (let z = 0; z < MAP_SIZE; z++) {
            let n = (noise2D(x * 0.035, z * 0.035) * 1.0 + noise2D(x * 0.09, z * 0.09) * 0.35) / 1.35;
            heightMap[x][z] = n;
            mapGrid[x][z] = 0;
        }
    }

    // River winding across center
    for (let x = 0; x < MAP_SIZE; x++) {
        let offset = Math.sin(x * 0.1) * 14.0 + (noise2D(x * 0.05, 24.0) - 0.5) * 16.0;
        let rz = Math.floor(MAP_SIZE / 2 + offset);
        rz = Math.max(5, Math.min(MAP_SIZE - 7, rz));
        mapGrid[x][rz] = 1;
        mapGrid[x][rz + 1] = 1;
        mapGrid[x][rz + 2] = 1;
    }

    // Mountain logic (block spawns)
    for (let sx = 0; sx < MAP_SIZE; sx += 5) {
        for (let sz = 0; sz < MAP_SIZE; sz += 5) {
            let hasRiver = false, totalVal = 0, counts = 0;
            for (let dx = 0; dx < 5; dx++) {
                for (let dz = 0; dz < 5; dz++) {
                    let rx = sx + dx, rz = sz + dz;
                    if (rx < MAP_SIZE && rz < MAP_SIZE) {
                        if (mapGrid[rx][rz] === 1) hasRiver = true;
                        totalVal += heightMap[rx][rz];
                        counts++;
                    }
                }
            }
            let avgVal = totalVal / counts;
            let inPlayArena = (sx >= 25 && sx <= 95 && sz >= 25 && sz <= 95);
            if (avgVal > 0.58 && !hasRiver && !inPlayArena) {
                for (let dx = 0; dx < 5; dx++) {
                    for (let dz = 0; dz < 5; dz++) {
                        let rx = sx + dx, rz = sz + dz;
                        if (rx < MAP_SIZE && rz < MAP_SIZE) mapGrid[rx][rz] = 2;
                    }
                }
            }
        }
    }

    // Highlands
    for (let x = 0; x < MAP_SIZE; x++) {
        for (let z = 0; z < MAP_SIZE; z++) {
            if (mapGrid[x][z] === 1 || mapGrid[x][z] === 2) continue;
            let val = heightMap[x][z];
            if (val > 0.52) mapGrid[x][z] = 3;
        }
    }

    // Terrain mesh
    terrainGeo = new THREE.PlaneGeometry(MAP_SIZE, MAP_SIZE, MAP_SIZE - 1, MAP_SIZE - 1);
    terrainGeo.rotateX(-Math.PI / 2);
    const pos = terrainGeo.attributes.position.array;
    for (let i = 0; i < pos.length; i += 3) {
        let x = Math.round(pos[i] + MAP_SIZE / 2);
        let z = Math.round(pos[i + 2] + MAP_SIZE / 2);
        let tx = Math.max(0, Math.min(MAP_SIZE - 1, x));
        let tz = Math.max(0, Math.min(MAP_SIZE - 1, z));
        let h = heightMap[tx][tz];
        let tileType = mapGrid[tx][tz];
        let worldH = 0;
        if (tileType === 1) worldH = -0.8;
        else if (tileType === 2) worldH = 4.0 + h * 8.0;
        else if (tileType === 3) worldH = 1.0 + h * 2.0;
        else worldH = h * 0.5 - 0.2;
        pos[i + 1] = worldH;
    }
    terrainGeo.computeVertexNormals();

    const vShader = `
      varying vec3 vNorm;
      varying vec3 vPos;
      void main() {
        vNorm = normalize(normalMatrix * normal);
        vPos = (modelMatrix * vec4(position, 1.0)).xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `;
    const fShader = `
      uniform vec3 colorGrass;
      uniform vec3 colorHighland;
      uniform vec3 colorMountain;
      uniform vec3 colorSnow;
      uniform vec3 colorRiver;
      uniform float uCinematic;
      varying vec3 vNorm;
      varying vec3 vPos;
      void main() {
         float h = vPos.y;
         vec3 finalColor = colorGrass;
         if (h < -0.1) finalColor = colorRiver;
         else if (h < 1.0) finalColor = mix(colorGrass, colorHighland, smoothstep(0.0, 1.0, h));
         else if (h < 4.5) finalColor = mix(colorHighland, colorMountain, smoothstep(1.0, 4.5, h));
         else finalColor = mix(colorMountain, colorSnow, smoothstep(4.5, 9.0, h));

         float diff = max(0.0, dot(vNorm, normalize(vec3(8.0, 10.0, 5.0))));
         diff = floor(diff * 4.0) / 4.0;

         vec3 lit = finalColor * (diff * 0.4 + 0.6);

         vec3 warm = lit * vec3(1.15, 0.92, 0.72);
         lit = mix(lit, warm, uCinematic * 0.55);

         gl_FragColor = vec4(lit, 1.0);
      }
    `;
    terrainMat = new THREE.ShaderMaterial({
        vertexShader: vShader,
        fragmentShader: fShader,
        uniforms: {
            colorGrass:    { value: new THREE.Color('#3fbf6e') },
            colorHighland: { value: new THREE.Color('#2ca376') },
            colorMountain: { value: new THREE.Color('#586472') },
            colorSnow:     { value: new THREE.Color('#e3eaf2') },
            colorRiver:    { value: new THREE.Color('#2aa6c9') },
            uCinematic:    { value: 0.0 }
        }
    });
    terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
    scene.add(terrainMesh);

    // Procedural Trees (Low Poly + Draw Call Optimization)
    const treePositions = [];
    const treeScaleMod = 1.8;
    for (let x = 0; x < MAP_SIZE; x++) {
        for (let z = 0; z < MAP_SIZE; z++) {
            if (mapGrid[x][z] === 0 || mapGrid[x][z] === 3) {
                let n = noise2D(x * 0.3, z * 0.3) * 0.5 + noise2D(x * 0.1, z * 0.1) * 0.5;
                if (n > 0.60) {
                    let inPlayArena = (x >= 32 && x <= 88 && z >= 32 && z <= 88);
                    
                    // Prevent trees near spawn spots
                    let wx = x - MAP_SIZE / 2;
                    let wz = z - MAP_SIZE / 2;
                    let nearBase = Math.hypot(wx - 0, wz - 38) < 8 ||
                                   Math.hypot(wx - (-22), wz - (-32)) < 8 ||
                                   Math.hypot(wx - 0, wz - (-42)) < 8 ||
                                   Math.hypot(wx - 22, wz - (-32)) < 8;
                    let nearGem = Math.hypot(wx - (-18), wz - 6) < 6 ||
                                  Math.hypot(wx - 18, wz - 6) < 6 ||
                                  Math.hypot(wx - (-22), wz - (-10)) < 6 ||
                                  Math.hypot(wx - 22, wz - (-10)) < 6 ||
                                  Math.hypot(wx - 0, wz - 14) < 6 ||
                                  Math.hypot(wx - (-10), wz - 20) < 6 ||
                                  Math.hypot(wx - 10, wz - 20) < 6;

                    if (!inPlayArena && !nearBase && !nearGem && Math.random() < 0.4) {
                        let h = heightMap[x][z];
                        let worldH = (mapGrid[x][z] === 3) ? (1.0 + h * 2.0) : (h * 0.5 - 0.2);
                        mapGrid[x][z] = 4; // 4 = Tree Trunk Obstacle
                        treePositions.push({ x: wx, z: wz, y: worldH });
                    }
                }
            }
        }
    }

    if (treePositions.length > 0) {
        const trunkGeo = new THREE.CylinderGeometry(0.3 * treeScaleMod, 0.5 * treeScaleMod, 2.0 * treeScaleMod, 5);
        trunkGeo.translate(0, 1.0 * treeScaleMod, 0); // Origin at bottom
        const trunkMat = new THREE.MeshLambertMaterial({ color: '#5c4033' });
        const trunkMesh = new THREE.InstancedMesh(trunkGeo, trunkMat, treePositions.length);
        
        // Leaves placed high enough for players to walk under
        const leavesGeo = new THREE.DodecahedronGeometry(1.6 * treeScaleMod, 0);
        leavesGeo.translate(0, 2.8 * treeScaleMod, 0); 
        const leavesMat = new THREE.MeshLambertMaterial({ color: '#388e3c' });
        const leavesMesh = new THREE.InstancedMesh(leavesGeo, leavesMat, treePositions.length);

        const dummy = new THREE.Object3D();
        treePositions.forEach((pos, i) => {
            dummy.position.set(pos.x, pos.y, pos.z);
            dummy.rotation.set(0, Math.random() * Math.PI * 2, 0);
            const scale = 0.8 + Math.random() * 0.4;
            dummy.scale.set(scale, scale, scale);
            dummy.updateMatrix();
            trunkMesh.setMatrixAt(i, dummy.matrix);
            leavesMesh.setMatrixAt(i, dummy.matrix);
        });
        
        trunkMesh.instanceMatrix.needsUpdate = true;
        leavesMesh.instanceMatrix.needsUpdate = true;
        scene.add(trunkMesh);
        scene.add(leavesMesh);
    }
}

// ---------- BASES (destructible 3D structures) ----------

function _findFlatSpot(centerX, centerZ, radius) {
    const tries = [[0, 0]];
    for (let r = 1; r <= radius; r++) {
        for (let a = 0; a < 16; a++) {
            const ang = (a / 16) * Math.PI * 2;
            tries.push([Math.round(Math.cos(ang) * r), Math.round(Math.sin(ang) * r)]);
        }
    }
    for (const [dx, dz] of tries) {
        const wx = centerX + dx, wz = centerZ + dz;
        const gx = Math.floor(wx + MAP_SIZE / 2), gz = Math.floor(wz + MAP_SIZE / 2);
        if (gx >= 1 && gx < MAP_SIZE - 1 && gz >= 1 && gz < MAP_SIZE - 1) {
            const t = mapGrid[gx][gz];
            if (t === 0 || t === 3) return { x: wx, z: wz };
        }
    }
    return { x: centerX, z: centerZ };
}

function buildBaseMesh(isPlayer, scaleMod) {
    const group = new THREE.Group();
    const stoneCol = isPlayer ? '#c8d6e5' : '#6b5b73';
    const roofCol  = isPlayer ? '#2e86de' : '#8b1e3f';
    const bannerCol= isPlayer ? '#2e86de' : '#8b1e3f';

    const base = new THREE.Mesh(
        new THREE.BoxGeometry(5 * scaleMod, 1.2, 5 * scaleMod),
        new THREE.MeshLambertMaterial({ color: '#3d3a36' })
    );
    base.position.y = 0.6;
    group.add(base);

    const keep = new THREE.Mesh(
        new THREE.CylinderGeometry(2.0 * scaleMod, 2.3 * scaleMod, 5.0, 12),
        new THREE.MeshLambertMaterial({ color: stoneCol })
    );
    keep.position.y = 1.2 + 2.5;
    group.add(keep);

    const ringR = 2.0 * scaleMod;
    for (let i = 0; i < 10; i++) {
        const ang = (i / 10) * Math.PI * 2;
        const merlon = new THREE.Mesh(
            new THREE.BoxGeometry(0.5, 0.7, 0.5),
            new THREE.MeshLambertMaterial({ color: stoneCol })
        );
        merlon.position.set(Math.cos(ang) * ringR, 1.2 + 5.05, Math.sin(ang) * ringR);
        group.add(merlon);
    }

    const roof = new THREE.Mesh(
        new THREE.ConeGeometry(1.9 * scaleMod, 2.5, 10),
        new THREE.MeshLambertMaterial({ color: roofCol })
    );
    roof.position.y = 1.2 + 5.0 + 1.25;
    group.add(roof);

    const pole = new THREE.Mesh(
        new THREE.CylinderGeometry(0.08, 0.08, 4.0, 6),
        new THREE.MeshLambertMaterial({ color: '#2a1e15' })
    );
    pole.position.y = 1.2 + 5.0 + 2.5 + 1.5;
    group.add(pole);
    const flag = new THREE.Mesh(
        new THREE.PlaneGeometry(1.4, 0.9),
        new THREE.MeshBasicMaterial({ color: bannerCol, side: THREE.DoubleSide })
    );
    flag.position.set(0.7, 1.2 + 5.0 + 2.5 + 2.5, 0);
    group.add(flag);

    const door = new THREE.Mesh(
        new THREE.BoxGeometry(0.9, 1.3, 0.2),
        new THREE.MeshLambertMaterial({ color: '#3a2614' })
    );
    door.position.set(0, 1.2 + 0.65, 2.0 * scaleMod + 0.01);
    group.add(door);

    // ---- 3D Floating HP Bar (visible above the keep) ----
    const hpCanvas = document.createElement('canvas');
    hpCanvas.width = 512; hpCanvas.height = 128;
    const hpCtx = hpCanvas.getContext('2d');
    const hpTex = new THREE.CanvasTexture(hpCanvas);
    const hpSpriteMat = new THREE.SpriteMaterial({ map: hpTex, transparent: true, depthTest: false });
    hpSpriteMat.depthWrite = false;
    const hpSprite = new THREE.Sprite(hpSpriteMat);
    // Place it above the flag
    hpSprite.position.y = 1.2 + 5.0 + 2.5 + 4.2;
    hpSprite.scale.set(7.5, 1.9, 1);
    hpSprite.renderOrder = 999;
    group.add(hpSprite);

    return { group, flag, hpCanvas, hpCtx, hpTex, hpSprite, pole };
}

function spawnBase(worldX, worldZ, isPlayer, scaleMod = 1.0, maxHp = 400) {
    const spot = _findFlatSpot(worldX, worldZ, 6);
    const built = buildBaseMesh(isPlayer, scaleMod);
    built.group.position.set(spot.x, 0, spot.z);
    scene.add(built.group);

    // Clear surrounding mountains for an approach radius, then mark base footprint as obstacle (5 = base collision)
    const gx0 = Math.floor(spot.x + MAP_SIZE / 2), gz0 = Math.floor(spot.z + MAP_SIZE / 2);
    for (let dx = -3; dx <= 3; dx++) {
        for (let dz = -3; dz <= 3; dz++) {
            const gx = gx0 + dx, gz = gz0 + dz;
            if (gx >= 0 && gx < MAP_SIZE && gz >= 0 && gz < MAP_SIZE && mapGrid[gx][gz] === 2) {
                mapGrid[gx][gz] = 0;
            }
        }
    }
    // Mark the base footprint tiles as collision (value 5 = base obstacle)
    const colRad = Math.max(1, Math.round(2.0 * scaleMod));
    const baseFootprint = [];
    for (let dx = -colRad; dx <= colRad; dx++) {
        for (let dz = -colRad; dz <= colRad; dz++) {
            const dist = Math.hypot(dx, dz);
            if (dist > colRad + 0.3) continue;
            const gx = gx0 + dx, gz = gz0 + dz;
            if (gx >= 0 && gx < MAP_SIZE && gz >= 0 && gz < MAP_SIZE && (mapGrid[gx][gz] === 0 || mapGrid[gx][gz] === 3)) {
                mapGrid[gx][gz] = 5;
                baseFootprint.push({ gx, gz });
            }
        }
    }

    const base = {
        group: built.group, flag: built.flag,
        hpCanvas: built.hpCanvas, hpCtx: built.hpCtx, hpTex: built.hpTex, hpSprite: built.hpSprite,
        x: spot.x, z: spot.z, isPlayer,
        radius: 2.4 * scaleMod,
        maxHp, currentHp: maxHp,
        destroyed: false,
        burnTimers: [],
        footprint: baseFootprint,
        scaleMod: scaleMod,
        uid: nextEntityId++
    };
    base.hpSprite.visible = true; // Show the 3D floating HP bar above the keep
    bases.push(base);
    if (isPlayer) playerBase = base; else enemyBases.push(base);
    drawBaseHp(base);
    return base;
}

function drawBaseHp(base) {
    const c = base.hpCanvas, ctx = base.hpCtx;
    const W = c.width, H = c.height;
    ctx.clearRect(0, 0, W, H);

    // Background panel (rounded)
    ctx.fillStyle = 'rgba(0,0,0,0.72)';
    const pad = 6;
    const r = 18;
    const px = pad, py = pad, pw = W - pad * 2, ph = H - pad * 2;
    ctx.beginPath();
    ctx.moveTo(px + r, py);
    ctx.lineTo(px + pw - r, py); ctx.arcTo(px + pw, py, px + pw, py + r, r);
    ctx.lineTo(px + pw, py + ph - r); ctx.arcTo(px + pw, py + ph, px + pw - r, py + ph, r);
    ctx.lineTo(px + r, py + ph); ctx.arcTo(px, py + ph, px, py + ph - r, r);
    ctx.lineTo(px, py + r); ctx.arcTo(px, py, px + r, py, r);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = base.isPlayer ? '#2ed573' : '#ff4757';
    ctx.lineWidth = 4; ctx.stroke();

    // Label
    ctx.font = 'bold 36px "Cinzel", "Arial Rounded MT Bold", serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.lineWidth = 6; ctx.strokeStyle = '#000';
    const label = base.isPlayer ? '🏰 Your Keep' : '⚑ Enemy Keep';
    ctx.strokeText(label, W / 2, 32);
    ctx.fillStyle = base.isPlayer ? '#7bed9f' : '#ff8a93';
    ctx.fillText(label, W / 2, 32);

    // HP bar background
    const barX = 30, barY = 60, barW = W - 60, barH = 36;
    ctx.fillStyle = '#000';
    ctx.fillRect(barX, barY, barW, barH);
    const pct = Math.max(0, base.currentHp / base.maxHp);
    const grad = ctx.createLinearGradient(barX, 0, barX + barW, 0);
    if (base.isPlayer) { grad.addColorStop(0, '#2ed573'); grad.addColorStop(1, '#7bed9f'); }
    else               { grad.addColorStop(0, '#ff4757'); grad.addColorStop(1, '#ff7f8a'); }
    ctx.fillStyle = grad;
    ctx.fillRect(barX + 2, barY + 2, (barW - 4) * pct, barH - 4);
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 3;
    ctx.strokeRect(barX, barY, barW, barH);

    // HP numbers overlaid
    ctx.font = 'bold 24px "Arial Rounded MT Bold", sans-serif';
    ctx.textBaseline = 'middle';
    ctx.lineWidth = 4; ctx.strokeStyle = '#000';
    const hpText = Math.max(0, base.currentHp | 0) + ' / ' + base.maxHp;
    ctx.strokeText(hpText, W / 2, barY + barH / 2);
    ctx.fillStyle = '#fff';
    ctx.fillText(hpText, W / 2, barY + barH / 2);

    base.hpTex.needsUpdate = true;
}

function damageBase(base, amount, attacker) {
    if (base.destroyed) return;
    base.currentHp -= amount;
    drawBaseHp(base);
    triggerFloatingText(amount.toString(), base.x + (Math.random() - 0.5) * 3, 5, base.z + (Math.random() - 0.5) * 3, base.isPlayer ? '#ff4757' : '#ffd166');
    triggerLivelyEmoji('💥', base.x + (Math.random() - 0.5) * 2, 3.5, base.z + (Math.random() - 0.5) * 2, 'normal_hit', null);
    shakeCamera(0.18, 0.25);
    // Emit base-hit sound at the keep's world position for distance attenuation
    if (window.SFX) SFX.play('baseHit', { x: base.x, z: base.z });
    if (base.currentHp <= 0) destroyBase(base);
}

function destroyBase(base) {
    if (base.destroyed) return;
    base.destroyed = true;
    base.currentHp = 0;
    drawBaseHp(base);
    logEvent((base.isPlayer ? "💔 Your keep has fallen!" : "🏰 Enemy keep destroyed!"), base.isPlayer ? '#ff4757' : '#ffd166');
    // Massive collapse — emit at the destroyed keep's position
    if (window.SFX) SFX.play('baseDestroyed', { x: base.x, z: base.z });

    // ---- Remove base collision tiles so units can walk over the ruins ----
    if (base.footprint) {
        for (const t of base.footprint) {
            if (mapGrid[t.gx] && mapGrid[t.gx][t.gz] === 5) {
                mapGrid[t.gx][t.gz] = 0;
            }
        }
        base.footprint = [];
    }
    // Hide the 3D HP bar after destruction
    if (base.hpSprite) base.hpSprite.visible = false;

    base.collapseT = 0;
    base.collapseDuration = 1.6;

    for (let i = 0; i < 12; i++) {
        setTimeout(() => {
            const ox = (Math.random() - 0.5) * 3, oz = (Math.random() - 0.5) * 3;
            triggerLivelyEmoji(Math.random() < 0.5 ? '🔥' : '💨', base.x + ox, 3 + Math.random() * 3, base.z + oz, 'normal_hit', null);
        }, i * 90);
    }
    shakeCamera(0.55, 1.2);
    triggerSlowMo(0.35, 0.9);

    triggerCinematic('base_destroyed', { x: base.x, z: base.z, isPlayer: base.isPlayer });

    setTimeout(() => checkVictoryCondition(), 2400);
}

function updateBases(dt) {
    for (const b of bases) {
        if (b.flag) b.flag.rotation.y = Math.sin(clock.elapsedTime * 1.5 + b.x) * 0.5;
        // Gentle bob for the floating HP bar so it feels alive
        if (b.hpSprite && b.hpSprite.visible) {
            const baseY = 1.2 + 5.0 + 2.5 + 4.2;
            b.hpSprite.position.y = baseY + Math.sin(clock.elapsedTime * 1.6 + b.x) * 0.18;
        }
        if (b.destroyed && b.collapseT !== undefined && b.collapseT < b.collapseDuration) {
            b.collapseT += dt;
            const p = Math.min(1, b.collapseT / b.collapseDuration);
            b.group.rotation.z = p * 0.35 * (b.x < 0 ? 1 : -1);
            b.group.position.y = -p * 3.0;
            b.group.scale.y = 1.0 - p * 0.3;
        }
    }
}

// Find the nearest base within `range` of a position. Used for archers attacking keeps & for base-aware AI.
function findNearestBase(x, z, hostileToPlayer) {
    let best = null, bd = 99999;
    for (const b of bases) {
        if (b.destroyed) continue;
        // hostileToPlayer = true means we want bases that ARE the player (enemy seeking) — keep generic instead
        if (hostileToPlayer === true && !b.isPlayer) continue;
        if (hostileToPlayer === false && b.isPlayer) continue;
        const d = Math.hypot(b.x - x, b.z - z);
        if (d < bd) { bd = d; best = b; }
    }
    return best;
}
window.findNearestBase = findNearestBase;

function checkVictoryCondition() {
    if (matchResult) return;
    if (playerBase && playerBase.destroyed) {
        matchResult = 'defeat';
        triggerCinematic('defeat', {});
        setTimeout(() => showEndScreen('defeat'), 2500);
    } else if (enemyBases.every(b => b.destroyed)) {
        matchResult = 'victory';
        triggerCinematic('victory', {});
        setTimeout(() => showEndScreen('victory'), 2500);
    }
}

// ===========================================================
// GEM DEPOSITS — mineable resource nodes scattered on the field
// ===========================================================

function buildGemDepositMesh() {
    const group = new THREE.Group();
    // Base rock
    const rock = new THREE.Mesh(
        new THREE.DodecahedronGeometry(1.0, 0),
        new THREE.MeshLambertMaterial({ color: '#3a3540' })
    );
    rock.position.y = 0.5;
    rock.rotation.set(Math.random(), Math.random(), Math.random());
    group.add(rock);
    // Crystal cluster
    const crystalCol = '#5fdfff';
    for (let i = 0; i < 5; i++) {
        const c = new THREE.Mesh(
            new THREE.ConeGeometry(0.22 + Math.random() * 0.12, 0.9 + Math.random() * 0.5, 5),
            new THREE.MeshLambertMaterial({ color: crystalCol, emissive: '#1a6b8a', emissiveIntensity: 0.6 })
        );
        c.position.set((Math.random() - 0.5) * 0.9, 0.8 + Math.random() * 0.3, (Math.random() - 0.5) * 0.9);
        c.rotation.set((Math.random() - 0.5) * 0.6, Math.random() * Math.PI, (Math.random() - 0.5) * 0.6);
        group.add(c);
    }
    // Sparkle sprite
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 128;
    const ctx = canvas.getContext('2d');
    ctx.shadowColor = 'rgba(95, 223, 255, 0.9)'; ctx.shadowBlur = 18;
    ctx.font = '70px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('💎', 64, 64);
    const tex = new THREE.CanvasTexture(canvas);
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
    sprite.position.y = 2.4;
    sprite.scale.set(1.4, 1.4, 1);
    group.add(sprite);
    return { group, sprite };
}

function spawnGemDeposit(worldX, worldZ, amount) {
    const spot = _findFlatSpot(worldX, worldZ, 5);
    const built = buildGemDepositMesh();
    built.group.position.set(spot.x, 0, spot.z);
    scene.add(built.group);
    const dep = {
        group: built.group, sparkle: built.sprite,
        x: spot.x, z: spot.z,
        remaining: amount,
        maxAmount: amount,
        mineLockBy: null,        // entity currently mining (cooperative lock so multiple don't overlap on same node)
        lockExpire: 0
    };
    gemDeposits.push(dep);
    return dep;
}

function spawnInitialGemDeposits() {
    // Spawn 5 deposits scattered in contested mid + sides; avoid bases & water
    const candidates = [
        { x: -18, z: 6 },
        { x:  18, z: 6 },
        { x: -22, z: -10 },
        { x:  22, z: -10 },
        { x:   0, z: 14 },
        { x: -10, z: 20 },
        { x:  10, z: 20 }
    ];
    for (const c of candidates) {
        spawnGemDeposit(c.x, c.z, 12 + Math.floor(Math.random() * 6));
    }
}

function updateGemDeposits(dt) {
    for (let i = gemDeposits.length - 1; i >= 0; i--) {
        const d = gemDeposits[i];
        if (d.sparkle) {
            d.sparkle.position.y = 2.4 + Math.sin(clock.elapsedTime * 2 + d.x) * 0.18;
            // Pulse scale based on remaining
            const pct = d.remaining / d.maxAmount;
            const s = 0.7 + pct * 0.8 + Math.sin(clock.elapsedTime * 3) * 0.07;
            d.sparkle.scale.set(s, s, 1);
        }
        if (d.lockExpire > 0 && clock.elapsedTime > d.lockExpire) {
            d.mineLockBy = null; d.lockExpire = 0;
        }
        if (d.remaining <= 0) {
            scene.remove(d.group);
            gemDeposits.splice(i, 1);
        }
    }
}

function findNearestDeposit(x, z) {
    let best = null, bd = 9999;
    for (const d of gemDeposits) {
        if (d.remaining <= 0) continue;
        const dist = Math.hypot(d.x - x, d.z - z);
        if (dist < bd) { bd = dist; best = d; }
    }
    return best;
}

// ---------- Dropped gem piles (when a carrier dies) ----------

function spawnDroppedGems(x, z, amount, ownerIsPlayer) {
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 128;
    const ctx = canvas.getContext('2d');
    ctx.shadowColor = 'rgba(95, 223, 255, 0.9)'; ctx.shadowBlur = 14;
    ctx.font = '74px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('💠', 64, 64);
    const tex = new THREE.CanvasTexture(canvas);
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
    sprite.position.set(x, 1.2, z);
    sprite.scale.set(1.2, 1.2, 1);
    scene.add(sprite);
    droppedGems.push({ mesh: sprite, x, z, amount, age: 0, originIsPlayer: ownerIsPlayer });
}

function updateDroppedGems(dt) {
    for (let i = droppedGems.length - 1; i >= 0; i--) {
        const g = droppedGems[i];
        g.age += dt;
        if (g.mesh) g.mesh.position.y = 1.2 + Math.sin(clock.elapsedTime * 3 + g.x) * 0.2;
        // Expire after 30s
        if (g.age > 30) {
            scene.remove(g.mesh);
            droppedGems.splice(i, 1);
        }
    }
}

function findNearestDroppedPile(x, z) {
    let best = null, bd = 999;
    for (const g of droppedGems) {
        const d = Math.hypot(g.x - x, g.z - z);
        if (d < bd) { bd = d; best = g; }
    }
    return best;
}

window.setupMap = setupMap;
window.spawnBase = spawnBase;
window.spawnInitialGemDeposits = spawnInitialGemDeposits;
window.updateBases = updateBases;
window.updateGemDeposits = updateGemDeposits;
window.updateDroppedGems = updateDroppedGems;
window.damageBase = damageBase;
window.findNearestDeposit = findNearestDeposit;
window.spawnDroppedGems = spawnDroppedGems;
window.findNearestDroppedPile = findNearestDroppedPile;
window.destroyBase = destroyBase;
