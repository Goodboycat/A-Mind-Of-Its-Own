// ===========================================================
// SOUNDS — Banners of Amoio (Token Game Jam 1 Edition)
// -----------------------------------------------------------
// Self-contained WebAudio sound manager. No external assets.
// All sounds are synthesized procedurally so the game stays
// 100% offline & dependency-free — perfect for a jam build.
//
// Usage anywhere in the codebase:
//     SFX.play('click');
//     SFX.play('attackHit');
//     SFX.setMuted(true);
//     SFX.setVolume(0.4);
//
// Sound bank:
//   click, deploy, recruit, mineHit, gemPickup, gemRefined,
//   depositDepleted, attackHit, arrowShoot, unitDie, baseHit,
//   baseDestroyed, phaseChange, prepStart, combatStart,
//   victory, defeat, praise, retreat, rally, error
// ===========================================================

(function () {
    const SFX = {
        _ctx: null,
        _master: null,
        _muted: false,
        _volume: 0.55,
        _initialized: false,
        // ----- Positional audio config -----
        // World-space distance at which sounds become fully inaudible.
        // The map spans ±60 world units; a value of ~55 means a battle on the
        // far side of the map will be silent while the camera is at the near side.
        _maxAudibleDist: 55,
        // Distance below which sounds play at full volume ("near field" radius).
        // Within this, no attenuation — prevents whisper-quiet sounds when the
        // camera is right on top of the action.
        _nearFieldDist: 8,
        // Per-frame attenuation cache: we recompute the camera-focus position
        // only when needed (cheap, but no point doing it twice in one play call).
        _lastAtten: 1.0,
        // Per-sound-name last-played timestamps. Used to dedupe high-frequency
        // sounds (e.g. 5 units dying on the same frame -> only one 'unitDie').
        _lastPlayed: Object.create(null),
        // Minimum interval (seconds) between two plays of the same sound name.
        // Per-name overrides live in _dedupMs below; default ~30ms.
        _dedupDefault: 0.030,
        _dedupMs: {
            attackHit:        0.035,
            arrowShoot:       0.050,
            mineHit:          0.060,
            unitDie:          0.080,
            baseHit:          0.060,
            gemPickup:        0.060,
            gemRefined:       0.080,
            depositDepleted:  0.150,
            click:            0.040,
            error:            0.080,
        },

        // Lazy init: WebAudio requires a user gesture in most browsers.
        // We hook init to the first click/touch on the document.
        _ensureCtx() {
            if (this._ctx) return this._ctx;
            try {
                const AC = window.AudioContext || window.webkitAudioContext;
                if (!AC) return null;
                this._ctx = new AC();
                this._master = this._ctx.createGain();
                this._master.gain.value = this._volume;
                this._master.connect(this._ctx.destination);
            } catch (e) {
                console.warn('[SFX] WebAudio not available', e);
            }
            return this._ctx;
        },

        setMuted(m) {
            this._muted = !!m;
            if (this._master) this._master.gain.value = this._muted ? 0 : this._volume;
            try { localStorage.setItem('amoio_sfx_muted', this._muted ? '1' : '0'); } catch (e) {}
        },
        toggleMuted() { this.setMuted(!this._muted); return this._muted; },
        isMuted() { return this._muted; },

        setVolume(v) {
            this._volume = Math.max(0, Math.min(1, v));
            if (this._master && !this._muted) this._master.gain.value = this._volume;
            try { localStorage.setItem('amoio_sfx_vol', String(this._volume)); } catch (e) {}
        },

        // ----- Positional / camera-distance helpers -----
        // Returns the world-space (x, z) point the camera is currently looking at
        // on the ground plane. The render loop calls
        //   camera.lookAt(camera.position.x, 0, camera.position.z - 15)
        // so the focal point is offset 15 units along -Z from the camera.
        _getListenerXZ() {
            const cam = window.camera;
            if (!cam || !cam.position) return null;
            return { x: cam.position.x, z: cam.position.z - 15 };
        },
        // Compute a 0..1 attenuation factor for a sound emitted at world (x, z).
        // Falloff is quadratic past the near-field radius for a natural feel.
        _attenuationAt(x, z) {
            if (x == null || z == null) return 1.0;
            const L = this._getListenerXZ();
            if (!L) return 1.0;
            const dx = x - L.x, dz = z - L.z;
            const d = Math.hypot(dx, dz);
            if (d <= this._nearFieldDist) return 1.0;
            if (d >= this._maxAudibleDist) return 0.0;
            // Linear range 0..1, then squared for nicer perceived falloff
            const t = 1.0 - (d - this._nearFieldDist) / (this._maxAudibleDist - this._nearFieldDist);
            return t * t;
        },
        // Public helper for other code (entities.js/map.js) to test audibility
        // before doing expensive work — currently unused but exposed for future use.
        isAudibleAt(x, z) { return this._attenuationAt(x, z) > 0.01; },

        // ---------- core synth helpers ----------
        _tone(opts) {
            const ctx = this._ensureCtx();
            if (!ctx || this._muted) return;
            const {
                type = 'sine', freq = 440, freqEnd = null,
                dur = 0.15, attack = 0.005, decay = 0.05,
                sustain = 0.2, release = 0.08,
                vol = 0.3, delay = 0, pan = 0
            } = opts;
            // Apply current per-call positional attenuation (set inside play()).
            const attenuatedVol = vol * (this._lastAtten != null ? this._lastAtten : 1.0);
            if (attenuatedVol < 0.001) return; // inaudible — skip work
            const t0 = ctx.currentTime + delay;
            const osc = ctx.createOscillator();
            osc.type = type;
            osc.frequency.setValueAtTime(freq, t0);
            if (freqEnd !== null) osc.frequency.exponentialRampToValueAtTime(Math.max(1, freqEnd), t0 + dur);

            const gain = ctx.createGain();
            gain.gain.setValueAtTime(0, t0);
            gain.gain.linearRampToValueAtTime(attenuatedVol, t0 + attack);
            gain.gain.linearRampToValueAtTime(attenuatedVol * sustain, t0 + attack + decay);
            gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur + release);

            let node = gain;
            if (pan !== 0 && ctx.createStereoPanner) {
                const p = ctx.createStereoPanner();
                p.pan.value = pan;
                gain.connect(p);
                node = p;
            }
            osc.connect(gain);
            node.connect(this._master);
            osc.start(t0);
            osc.stop(t0 + dur + release + 0.02);
        },

        _noise(opts) {
            const ctx = this._ensureCtx();
            if (!ctx || this._muted) return;
            const {
                dur = 0.18, vol = 0.25, delay = 0,
                filterFreq = 1200, filterQ = 1, filterType = 'bandpass',
                attack = 0.005, release = 0.1
            } = opts;
            const attenuatedVol = vol * (this._lastAtten != null ? this._lastAtten : 1.0);
            if (attenuatedVol < 0.001) return;
            const t0 = ctx.currentTime + delay;
            const bufSize = Math.floor(ctx.sampleRate * dur);
            const buffer = ctx.createBuffer(1, bufSize, ctx.sampleRate);
            const data = buffer.getChannelData(0);
            for (let i = 0; i < bufSize; i++) data[i] = (Math.random() * 2 - 1);

            const src = ctx.createBufferSource();
            src.buffer = buffer;

            const filter = ctx.createBiquadFilter();
            filter.type = filterType;
            filter.frequency.value = filterFreq;
            filter.Q.value = filterQ;

            const gain = ctx.createGain();
            gain.gain.setValueAtTime(0, t0);
            gain.gain.linearRampToValueAtTime(attenuatedVol, t0 + attack);
            gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur + release);

            src.connect(filter); filter.connect(gain); gain.connect(this._master);
            src.start(t0); src.stop(t0 + dur + release + 0.02);
        },

        // ---------- sound bank ----------
        // play(name)                     — plays at full volume (UI / non-positional sound)
        // play(name, { x, z })           — plays attenuated by distance from camera focus
        // play(name, { entity })         — convenience: uses entity.px / entity.pz
        // play(name, { base })           — convenience: uses base.x  / base.z
        play(name, opts) {
            if (this._muted) return;
            this._ensureCtx();

            // ----- Resolve emitter position (if any) -----
            let ex = null, ez = null;
            if (opts) {
                if (opts.entity && typeof opts.entity.px === 'number') { ex = opts.entity.px; ez = opts.entity.pz; }
                else if (opts.base && typeof opts.base.x === 'number') { ex = opts.base.x;   ez = opts.base.z;  }
                else if (typeof opts.x === 'number' && typeof opts.z === 'number') { ex = opts.x; ez = opts.z; }
            }

            // ----- Per-name dedup (action-heavy moments) -----
            // Skip if the same sound was triggered very recently. Uses the audio
            // clock so it stays correct under slowMo / tab-throttling.
            const ctxNow = (this._ctx && this._ctx.currentTime) || (performance.now() / 1000);
            const minGap = this._dedupMs[name] != null ? this._dedupMs[name] : this._dedupDefault;
            const last = this._lastPlayed[name];
            if (last != null && (ctxNow - last) < minGap) return;
            this._lastPlayed[name] = ctxNow;

            // ----- Compute & cache positional attenuation for this play call -----
            this._lastAtten = (ex != null) ? this._attenuationAt(ex, ez) : 1.0;
            if (this._lastAtten < 0.005) { this._lastAtten = 1.0; return; } // too far — silent

            const r = (a, b) => a + Math.random() * (b - a);

            switch (name) {
                // --- UI ---
                case 'click':
                    this._tone({ type: 'square', freq: 720, freqEnd: 540, dur: 0.06, vol: 0.18, attack: 0.001, decay: 0.02, sustain: 0.4, release: 0.05 });
                    break;
                case 'error':
                    this._tone({ type: 'square', freq: 220, freqEnd: 140, dur: 0.18, vol: 0.22, sustain: 0.6 });
                    break;

                // --- Economy ---
                case 'deploy':
                    // Banner unfurl: brassy chord
                    this._tone({ type: 'triangle', freq: 330, dur: 0.18, vol: 0.22 });
                    this._tone({ type: 'triangle', freq: 494, dur: 0.22, vol: 0.18, delay: 0.04 });
                    this._tone({ type: 'sine',     freq: 660, dur: 0.28, vol: 0.14, delay: 0.08 });
                    break;
                case 'recruit':
                    // Gacha pull: rising arpeggio + sparkle
                    [523, 659, 784, 1046].forEach((f, i) =>
                        this._tone({ type: 'triangle', freq: f, dur: 0.12, vol: 0.2, delay: i * 0.07 })
                    );
                    this._noise({ dur: 0.25, vol: 0.08, filterFreq: 6000, filterQ: 4, delay: 0.25 });
                    break;

                // --- Mining / Gems ---
                case 'mineHit':
                    // Pickaxe chip on rock: short metallic clink + dirt scrape
                    this._tone({ type: 'square', freq: r(1100, 1400), freqEnd: r(500, 700), dur: 0.06, vol: 0.18, sustain: 0.3 });
                    this._noise({ dur: 0.09, vol: 0.12, filterFreq: 3000, filterQ: 2, filterType: 'highpass' });
                    break;
                case 'gemPickup':
                    // Crystalline chime when carrier picks up a chunk
                    this._tone({ type: 'sine', freq: 1320, dur: 0.10, vol: 0.20 });
                    this._tone({ type: 'sine', freq: 1760, dur: 0.14, vol: 0.16, delay: 0.04 });
                    break;
                case 'gemRefined':
                    // Coin-purse / treasury cha-ching
                    [880, 1175, 1568, 2093].forEach((f, i) =>
                        this._tone({ type: 'sine', freq: f, dur: 0.18, vol: 0.18, delay: i * 0.05 })
                    );
                    break;
                case 'depositDepleted':
                    // Stone crumble — low rumble + descending tail
                    this._noise({ dur: 0.35, vol: 0.22, filterFreq: 400, filterQ: 1, filterType: 'lowpass' });
                    this._tone({ type: 'sawtooth', freq: 220, freqEnd: 60, dur: 0.4, vol: 0.18, sustain: 0.5 });
                    break;

                // --- Combat ---
                case 'attackHit':
                    // Sword/melee impact
                    this._tone({ type: 'square', freq: r(180, 260), freqEnd: r(60, 90), dur: 0.10, vol: 0.22, sustain: 0.5 });
                    this._noise({ dur: 0.12, vol: 0.18, filterFreq: 1800, filterQ: 1.5 });
                    break;
                case 'arrowShoot':
                    // Bow twang + whoosh
                    this._tone({ type: 'triangle', freq: 380, freqEnd: 220, dur: 0.08, vol: 0.18 });
                    this._noise({ dur: 0.22, vol: 0.10, filterFreq: 2500, filterQ: 3, filterType: 'bandpass', delay: 0.04 });
                    break;
                case 'unitDie':
                    // Falling tone, soft
                    this._tone({ type: 'triangle', freq: 420, freqEnd: 110, dur: 0.35, vol: 0.20, sustain: 0.4 });
                    this._noise({ dur: 0.18, vol: 0.10, filterFreq: 600, filterQ: 1, filterType: 'lowpass', delay: 0.05 });
                    break;
                case 'baseHit':
                    // Heavy thud against stone wall
                    this._tone({ type: 'sawtooth', freq: 140, freqEnd: 60, dur: 0.20, vol: 0.28, sustain: 0.6 });
                    this._noise({ dur: 0.20, vol: 0.18, filterFreq: 500, filterQ: 1.5, filterType: 'lowpass' });
                    break;
                case 'baseDestroyed':
                    // Massive collapse
                    this._noise({ dur: 0.9, vol: 0.32, filterFreq: 300, filterQ: 1, filterType: 'lowpass' });
                    this._tone({ type: 'sawtooth', freq: 110, freqEnd: 30, dur: 0.9, vol: 0.25, sustain: 0.6 });
                    [80, 90, 70].forEach((f, i) =>
                        this._tone({ type: 'triangle', freq: f, dur: 0.4, vol: 0.18, delay: 0.2 + i * 0.12 })
                    );
                    break;

                // --- Phase / commands ---
                case 'prepStart':
                    // Soft horn pair: prep
                    this._tone({ type: 'triangle', freq: 392, dur: 0.4, vol: 0.22, sustain: 0.5 });
                    this._tone({ type: 'triangle', freq: 523, dur: 0.5, vol: 0.20, sustain: 0.5, delay: 0.18 });
                    break;
                case 'combatStart':
                    // War horn: rising brass blast
                    this._tone({ type: 'sawtooth', freq: 196, freqEnd: 294, dur: 0.45, vol: 0.28, sustain: 0.6 });
                    this._tone({ type: 'sawtooth', freq: 247, freqEnd: 370, dur: 0.50, vol: 0.22, sustain: 0.6, delay: 0.08 });
                    this._tone({ type: 'triangle', freq: 392, dur: 0.6, vol: 0.18, sustain: 0.6, delay: 0.25 });
                    break;
                case 'phaseChange':
                    this._tone({ type: 'sine', freq: 660, dur: 0.12, vol: 0.18 });
                    this._tone({ type: 'sine', freq: 880, dur: 0.16, vol: 0.16, delay: 0.08 });
                    break;
                case 'rally':
                    // Ping/beacon: rising bell
                    this._tone({ type: 'sine', freq: 880,  dur: 0.18, vol: 0.20 });
                    this._tone({ type: 'sine', freq: 1320, dur: 0.22, vol: 0.18, delay: 0.06 });
                    this._tone({ type: 'sine', freq: 1760, dur: 0.30, vol: 0.14, delay: 0.12 });
                    break;
                case 'retreat':
                    // Falling horn
                    this._tone({ type: 'sawtooth', freq: 330, freqEnd: 165, dur: 0.45, vol: 0.24, sustain: 0.6 });
                    break;
                case 'praise':
                    // Heart chime: warm major third
                    this._tone({ type: 'sine', freq: 784,  dur: 0.20, vol: 0.20 });
                    this._tone({ type: 'sine', freq: 988,  dur: 0.24, vol: 0.18, delay: 0.05 });
                    this._tone({ type: 'sine', freq: 1175, dur: 0.30, vol: 0.16, delay: 0.10 });
                    break;

                // --- End screens ---
                case 'victory':
                    // Triumphant fanfare: I - IV - V - I (C major)
                    [
                        { f: 523, t: 0.00 }, { f: 659, t: 0.00 }, { f: 784, t: 0.00 },
                        { f: 698, t: 0.30 }, { f: 880, t: 0.30 },
                        { f: 784, t: 0.60 }, { f: 988, t: 0.60 },
                        { f: 1046, t: 0.95 }, { f: 1319, t: 0.95 }, { f: 1568, t: 0.95 }
                    ].forEach(n =>
                        this._tone({ type: 'triangle', freq: n.f, dur: 0.32, vol: 0.20, sustain: 0.6, delay: n.t })
                    );
                    // Sparkle tail
                    this._noise({ dur: 0.6, vol: 0.06, filterFreq: 7000, filterQ: 5, delay: 1.2 });
                    break;
                case 'defeat':
                    // Descending mournful minor
                    [
                        { f: 440, t: 0.00 },
                        { f: 392, t: 0.30 },
                        { f: 349, t: 0.60 },
                        { f: 262, t: 0.95 }
                    ].forEach(n =>
                        this._tone({ type: 'triangle', freq: n.f, dur: 0.45, vol: 0.22, sustain: 0.5, delay: n.t })
                    );
                    this._tone({ type: 'sawtooth', freq: 110, freqEnd: 55, dur: 1.4, vol: 0.18, sustain: 0.6, delay: 0.1 });
                    break;

                default:
                    // Unknown sound — silent fallback
                    break;
            }
            // Reset attenuation so the next non-positional play() defaults to full volume.
            this._lastAtten = 1.0;
        },

        // Restore saved settings, attach unlock-on-first-gesture listener.
        _bootstrap() {
            if (this._initialized) return;
            this._initialized = true;
            try {
                const m = localStorage.getItem('amoio_sfx_muted');
                if (m === '1') this._muted = true;
                const v = localStorage.getItem('amoio_sfx_vol');
                if (v !== null && !isNaN(parseFloat(v))) this._volume = parseFloat(v);
            } catch (e) {}

            const unlock = () => {
                this._ensureCtx();
                if (this._ctx && this._ctx.state === 'suspended') this._ctx.resume();
                document.removeEventListener('pointerdown', unlock);
                document.removeEventListener('keydown', unlock);
                document.removeEventListener('touchstart', unlock);
            };
            document.addEventListener('pointerdown', unlock, { once: false });
            document.addEventListener('keydown',     unlock, { once: false });
            document.addEventListener('touchstart',  unlock, { once: false });
        }
    };

    SFX._bootstrap();
    window.SFX = SFX;
})();
