// ===========================================================
// UI — inventory cards, deployed roster, order panel,
//      floating texts, speech bubbles, event log, end screens,
//      settings modal, UI visibility toggle
// ===========================================================

function renderInventory() {
    const list = document.getElementById('units-list');
    if (!list) return;
    list.innerHTML = '';
    playerInventory.forEach((u, index) => {
        const el = document.createElement('div');
        el.className = 'unit-card' + (selectedInvIndex === index ? ' selected' : '');
        el.title = `${u.name}\nHP: ${u.hp}  ATK: ${u.atk}  Speed: ${u.speed}\nLoyalty: ${u.loyalty}  Type: ${u.type}\nCost: ${u.cost} 💎`;
        el.innerHTML =
            '<div class="card-icon">' + getUnitIconHtml(u, '32px') + '</div>' +
            '<div class="card-name">' + shortName(u.name) + '</div>' +
            '<div class="card-stats">' + u.hp + ' HP · ' + u.atk + ' ATK</div>' +
            '<div class="card-cost">💎 ' + (u.cost || 0) + '</div>' +
            '<div class="loyalty-container"><div class="loyalty-bar" style="width:' + u.loyalty + '%"></div></div>';
        el.onclick = () => selectUnitForPlacement(index);
        list.appendChild(el);
    });
}
window.renderInventory = renderInventory;

function shortName(s) {
    if (s.length <= 12) return s;
    return s.slice(0, 11) + '…';
}

function selectUnitForPlacement(index) {
    if (gameState !== 'battle') return;
    if (selectedInvIndex === index) selectedInvIndex = -1;
    else selectedInvIndex = index;
    renderInventory();
}

function pullGacha() {
    const cost = (typeof RECRUIT_COST !== 'undefined') ? RECRUIT_COST : 10;
    if (gems >= cost) {
        gems -= cost;
        document.getElementById('gem-count').innerText = gems;
        const u = generateUnit();
        playerInventory.push(u);
        renderInventory();
        logEvent(`Recruited ${u.icon} ${u.name}`, '#ffd166');
        // Reflect new recruit cost in the button text in case it changed
        const btn = document.querySelector('.gacha-btn');
        if (btn) btn.innerText = `⚜ Recruit (${cost} 💎)`;
        if (window.SFX) SFX.play('recruit');
    } else {
        // Screen-fixed toast — no more world-space text drifting over terrain
        showScreenToast(`Need ${cost} 💎 to recruit`, 'error');
        if (window.SFX) SFX.play('error');
    }
}
window.pullGacha = pullGacha;

// ---------- DEPLOYED ROSTER PANEL ----------

function renderDeployedRoster() {
    const panel = document.getElementById('deployed-roster');
    if (!panel) return;
    panel.innerHTML = '';
    let any = false;
    entities.forEach((e, idx) => {
        if (!e.isPlayer) return;
        any = true;
        const isSel = (idx === selectedUnitIndex);
        const card = document.createElement('div');
        card.className = 'deployed-card' + (isSel ? ' selected' : '');
        const hpPct = Math.max(0, e.data.currentHp / e.data.maxHp) * 100;
        const orderIcon = ({ attack: '⚔️', defend: '🛡️', retreat: '🏃', hold: '🚩', ping: '📍', mine: '⛏️' })[e.order] || '';
        const carryHTML = e.carryAmount > 0 ? '<span class="dc-carry">💠' + e.carryAmount + '</span>' : '';
        card.innerHTML =
            '<div class="dc-icon">' + getUnitIconHtml(e.data, '22px') + '</div>' +
            '<div class="dc-info">' +
                '<div class="dc-name">' + shortName(e.data.name) + (orderIcon ? ' <span class="dc-order">' + orderIcon + '</span>' : '') + carryHTML + '</div>' +
                '<div class="dc-hpbar"><div class="dc-hpfill" style="width:' + hpPct.toFixed(0) + '%"></div></div>' +
            '</div>';
        card.onclick = () => selectDeployedUnit(idx);
        panel.appendChild(card);
    });
    if (!any) panel.innerHTML = '<div class="roster-empty">No units deployed yet. Pick a card below and tap your half of the map.</div>';
}
window.renderDeployedRoster = renderDeployedRoster;

// ---------- ORDER PANEL ----------

function renderOrderPanel() {
    const panel = document.getElementById('order-panel');
    if (!panel) return;
    if (selectedUnitIndex < 0 || !entities[selectedUnitIndex]) {
        panel.classList.add('hidden');
        return;
    }
    const e = entities[selectedUnitIndex];
    panel.classList.remove('hidden');
    const carryNote = e.carryAmount > 0 ? ' · 💠' + e.carryAmount : '';
    panel.innerHTML =
        '<div class="op-header">' +
            '<span class="op-icon">' + getUnitIconHtml(e.data, '24px') + '</span>' +
            '<span class="op-name">' + e.data.name + '</span>' +
            '<button class="op-close" onclick="deselectUnit()">✖</button>' +
        '</div>' +
        '<div class="op-stats">HP ' + e.data.currentHp + '/' + e.data.maxHp +
            ' · ATK ' + e.data.atk + ' · Loy ' + e.data.loyalty + carryNote +
        '</div>' +
        '<div class="op-orders">' +
            '<button class="op-btn ' + (commandMode === 'attack' ? 'active' : '') + '" onclick="issueOrder(\'attack\')">⚔️ Attack</button>' +
            '<button class="op-btn ' + (e.order === 'defend' ? 'active' : '') + '" onclick="issueOrder(\'defend\')">🛡️ Defend</button>' +
            '<button class="op-btn ' + (e.order === 'mine' ? 'active' : '') + '" onclick="issueOrder(\'mine\')">⛏️ Mine</button>' +
            '<button class="op-btn ' + (e.order === 'retreat' ? 'active' : '') + '" onclick="issueOrder(\'retreat\')">🏃 Retreat</button>' +
            '<button class="op-btn ' + (commandMode === 'hold' ? 'active' : '') + '" onclick="issueOrder(\'hold\')">🚩 Hold</button>' +
            '<button class="op-btn ' + (commandMode === 'ping' ? 'active' : '') + '" onclick="issueOrder(\'ping\')">📍 Move</button>' +
            '<button class="op-btn cancel" onclick="issueOrder(\'cancel\')">✖ Clear Order</button>' +
        '</div>';
}
window.renderOrderPanel = renderOrderPanel;

// ---------- EVENT LOG ----------

function renderEventLog() {
    const log = document.getElementById('event-log');
    if (!log) return;
    log.innerHTML = '';
    eventLog.forEach(ev => {
        const div = document.createElement('div');
        div.className = 'event-line';
        div.style.color = ev.color || '#fff';
        div.style.opacity = Math.max(0.3, 1 - ev.age * 0.15);
        div.innerText = ev.text;
        log.appendChild(div);
    });
}
window.renderEventLog = renderEventLog;

window.logEvent = logEvent;
var logEvent = function(text, color = '#ffffff') {
    if (typeof eventLog === 'undefined') window.eventLog = [];
    eventLog.unshift({ text, color, age: 0 });
    if (eventLog.length > 5) eventLog.pop();
    if (window.renderEventLog) renderEventLog();
}

// ---------- HUD: base HP bars ----------

function renderBaseHUD() {
    const hud = document.getElementById('base-hud');
    if (!hud) return;
    if (!playerBase && enemyBases.length === 0) { hud.classList.add('hidden'); return; }
    hud.classList.remove('hidden');
    let html = '';
    if (playerBase) {
        const pct = Math.max(0, playerBase.currentHp / playerBase.maxHp) * 100;
        html += '<div class="hud-base player ' + (playerBase.destroyed ? 'destroyed' : '') + '">' +
            '<div class="hud-label">🏰 Your Keep</div>' +
            '<div class="hud-bar"><div class="hud-fill player-fill" style="width:' + pct.toFixed(0) + '%"></div></div>' +
            '<div class="hud-num">' + Math.max(0, playerBase.currentHp | 0) + '/' + playerBase.maxHp + '</div>' +
        '</div>';
    }
    if (enemyBases.length) {
        const alive = enemyBases.filter(b => !b.destroyed).length;
        const totalCur = enemyBases.reduce((s, b) => s + Math.max(0, b.currentHp), 0);
        const totalMax = enemyBases.reduce((s, b) => s + b.maxHp, 0);
        const pct = totalMax > 0 ? (totalCur / totalMax) * 100 : 0;
        html += '<div class="hud-base enemy">' +
            '<div class="hud-label">⚑ Enemy Keeps (' + alive + '/' + enemyBases.length + ')</div>' +
            '<div class="hud-bar"><div class="hud-fill enemy-fill" style="width:' + pct.toFixed(0) + '%"></div></div>' +
            '<div class="hud-num">' + (totalCur | 0) + '/' + totalMax + '</div>' +
        '</div>';
    }
    hud.innerHTML = html;
}
window.renderBaseHUD = renderBaseHUD;

// ---------- FLOATING TEXT & SPEECH BUBBLES ----------

let commandsMenuOpen = false;
function toggleCommandsMenu() {
    const list = document.getElementById('commands-list');
    const btn = document.getElementById('commands-toggle-btn');
    if (!list || !btn) return;
    commandsMenuOpen = !commandsMenuOpen;
    if (commandsMenuOpen) {
        list.classList.add('show');
        btn.classList.add('active');
        btn.innerText = '✖️';
    } else {
        list.classList.remove('show');
        btn.classList.remove('active');
        btn.innerText = '⚔️';
    }
}
window.toggleCommandsMenu = toggleCommandsMenu;

window.commanderPanelHidden = false;
function toggleCommanderPanel() {
    const panel = document.getElementById('commander-panel-container');
    const btn = document.getElementById('commander-toggle-btn');
    if (!panel || !btn) return;
    window.commanderPanelHidden = !window.commanderPanelHidden;
    if (window.commanderPanelHidden) {
        panel.classList.add('collapsed');
        btn.innerText = '▶';
        btn.classList.add('collapsed-btn');
    } else {
        panel.classList.remove('collapsed');
        btn.innerText = '◀';
        btn.classList.remove('collapsed-btn');
    }
    if (window.SFX) SFX.play('click');
}
window.toggleCommanderPanel = toggleCommanderPanel;

// ===== SOUND TOGGLE (top bar speaker button) =====
function toggleSound() {
    if (!window.SFX) return;
    const muted = SFX.toggleMuted();
    const btn = document.getElementById('sound-btn');
    if (btn) {
        btn.innerText = muted ? '🔇' : '🔊';
        btn.title = muted ? 'Sound Muted (tap to enable)' : 'Sound On (tap to mute)';
    }
    if (!muted && window.SFX) SFX.play('click');
    if (window.showScreenToast) showScreenToast(muted ? '🔇 Sound muted' : '🔊 Sound on', 'default');
}
window.toggleSound = toggleSound;

// On load, sync the speaker icon with saved mute state
document.addEventListener('DOMContentLoaded', () => {
    if (window.SFX && SFX.isMuted()) {
        const btn = document.getElementById('sound-btn');
        if (btn) { btn.innerText = '🔇'; btn.title = 'Sound Muted (tap to enable)'; }
    }
});

let inventoryHidden = false;
function toggleInventory() {
    const inv = document.getElementById('inventory');
    const btn = document.getElementById('inventory-toggle-btn');
    if (!inv || !btn) return;
    inventoryHidden = !inventoryHidden;
    if (inventoryHidden) {
        inv.classList.add('collapsed');
        btn.innerText = '▲';
        btn.classList.add('collapsed-btn');
    } else {
        inv.classList.remove('collapsed');
        btn.innerText = '▼';
        btn.classList.remove('collapsed-btn');
    }
}
window.toggleInventory = toggleInventory;

function triggerFloatingText(text, x, y, z, color) {
    const canvas = document.createElement('canvas');
    canvas.width = 256; canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.font = 'bold 36px "Arial Rounded MT Bold", sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.strokeStyle = '#000000'; ctx.lineWidth = 6;
    ctx.strokeText(text, 128, 32);
    ctx.fillStyle = color || '#ffffff'; ctx.fillText(text, 128, 32);

    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true }));
    sprite.position.set(x, y, z); sprite.scale.set(4, 1, 1);
    scene.add(sprite);
    floatingTexts.push({ sprite, age: 0 });
}

function triggerSpeechBubble(text, x, y, z, styleType, hostEntity = null) {
    // ---- Snap any existing speech bubble for this host to fade-out quickly ----
    if (hostEntity) {
        for (const item of livelyEmojis) {
            if (item.type === 'comic_speech' && item.host === hostEntity) {
                // Fast-forward existing bubble to the fade-out tail
                item.age = Math.max(item.age, item.maxAge * 0.85);
            }
        }
    }

    // ---- High-resolution bubble canvas for crisp readability ----
    const canvas = document.createElement('canvas');
    canvas.width = 512; canvas.height = 192;
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    const th = 28;     // tail height
    const ox = 10;     // outline inset
    const r = 26;      // corner radius
    ctx.beginPath();
    ctx.moveTo(ox + r, ox);
    ctx.lineTo(w - ox - r, ox); ctx.arcTo(w - ox, ox, w - ox, ox + r, r);
    ctx.lineTo(w - ox, h - th - ox - r); ctx.arcTo(w - ox, h - th - ox, w - ox - r, h - th - ox, r);
    ctx.lineTo(w / 2 + 28, h - th - ox);
    ctx.lineTo(w / 2, h - ox);
    ctx.lineTo(w / 2 - 28, h - th - ox);
    ctx.lineTo(ox + r, h - th - ox); ctx.arcTo(ox, h - th - ox, ox, h - th - ox - r, r);
    ctx.lineTo(ox, ox + r); ctx.arcTo(ox, ox, ox + r, ox, r);
    ctx.closePath();

    let bg = '#fffbe8', stroke = '#000000';
    if (styleType === 'victim') { bg = '#fff0f1'; stroke = '#ff4757'; }
    else if (styleType === 'attacker') { bg = '#eef1ff'; stroke = '#3742fa'; }
    else if (styleType === 'order') { bg = '#fffae0'; stroke = '#ffa502'; }

    // Soft drop-shadow
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.55)';
    ctx.shadowBlur = 14;
    ctx.shadowOffsetY = 6;
    ctx.fillStyle = bg; ctx.fill();
    ctx.restore();

    ctx.strokeStyle = stroke; ctx.lineWidth = 10; ctx.stroke();

    // ---- Word-wrap helper so longer text stays readable ----
    function wrapLines(words, maxW, font) {
        ctx.font = font;
        const lines = [];
        let line = '';
        for (const wd of words) {
            const test = line ? line + ' ' + wd : wd;
            if (ctx.measureText(test).width > maxW && line) {
                lines.push(line); line = wd;
            } else line = test;
        }
        if (line) lines.push(line);
        return lines;
    }

    // Pick a comfortable font size based on length
    let fs = 56;
    if (text.length > 8) fs = 48;
    if (text.length > 14) fs = 42;
    if (text.length > 22) fs = 36;
    if (text.length > 32) fs = 30;
    const font = 'bold ' + fs + 'px "Arial Rounded MT Bold", "Segoe UI", sans-serif';
    const words = text.split(/\s+/);
    const maxTextW = w - 60;
    let lines = wrapLines(words, maxTextW, font);
    // If still too tall, shrink and retry
    while (lines.length * (fs + 4) > h - th - 30 && fs > 22) {
        fs -= 4;
        const f2 = 'bold ' + fs + 'px "Arial Rounded MT Bold", "Segoe UI", sans-serif';
        lines = wrapLines(words, maxTextW, f2);
    }
    const finalFont = 'bold ' + fs + 'px "Arial Rounded MT Bold", "Segoe UI", sans-serif';
    ctx.font = finalFont;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#101820';

    const totalH = lines.length * (fs + 4) - 4;
    let startY = (h - th) / 2 - totalH / 2 + fs / 2;
    // Crisp 1px outline for extra contrast
    ctx.lineWidth = 4; ctx.strokeStyle = bg;
    for (let i = 0; i < lines.length; i++) {
        const ly = startY + i * (fs + 4);
        ctx.strokeText(lines[i], w / 2, ly);
        ctx.fillText(lines[i], w / 2, ly);
    }

    const spriteMat = new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, depthTest: false });
    spriteMat.depthWrite = false;
    const sprite = new THREE.Sprite(spriteMat);
    sprite.position.set(x, y, z); sprite.scale.set(0.01, 0.01, 0.01);
    sprite.renderOrder = 1000;
    scene.add(sprite);
    livelyEmojis.push({
        // Lift speech bubbles well clear of the fighters (was 2.4)
        // so combat animations and HP bars stay visible underneath.
        sprite, host: hostEntity, offsetY: 4.6, x, y, z,
        age: 0, maxAge: 2.6, type: 'comic_speech',
        // Aspect ratio (w / h) baked in so initialScale controls the visual height
        initialScale: 3.6, aspect: (w / h)
    });
}
window.triggerSpeechBubble = triggerSpeechBubble;

function triggerLivelyEmoji(emoji, x, y, z, type, hostEntity = null) {
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 128;
    const ctx = canvas.getContext('2d');
    ctx.shadowColor = 'rgba(0, 0, 0, 0.7)'; ctx.shadowBlur = 8; ctx.shadowOffsetY = 4;
    ctx.font = 'bold 70px Arial, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(emoji, 64, 64);
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true }));
    sprite.position.set(x, y, z); sprite.scale.set(0.01, 0.01, 0.01);
    scene.add(sprite);
    livelyEmojis.push({ sprite, host: hostEntity, offsetY: 1.6, x, y, z, age: 0, maxAge: 2.0, type, initialScale: 1.1 });
}

function updateFloatingTexts(dt) {
    for (let i = floatingTexts.length - 1; i >= 0; i--) {
        const ft = floatingTexts[i];
        ft.age += dt; ft.sprite.position.y += dt;
        ft.sprite.material.opacity = Math.max(0, 1 - (ft.age / 1.5));
        if (ft.age > 1.5) { scene.remove(ft.sprite); floatingTexts.splice(i, 1); }
    }
    for (const ev of eventLog) ev.age += dt;
    if (eventLog.length) renderEventLog();
}

window.updateLivelyEmojis = updateLivelyEmojis;
function updateLivelyEmojis(dt) {
    for (let i = livelyEmojis.length - 1; i >= 0; i--) {
        const item = livelyEmojis[i]; item.age += dt;
        let progress = item.age / item.maxAge;
        if (progress >= 1.0) { scene.remove(item.sprite); livelyEmojis.splice(i, 1); continue; }
        if (item.host && item.host.data && item.host.data.currentHp > 0) {
            item.x = item.host.mesh.position.x; item.y = item.host.mesh.position.y + item.offsetY; item.z = item.host.mesh.position.z;
        } else if (item.host) item.age += dt;
        let scale = 1.0;
        if (progress < 0.18) scale = Math.sin((progress / 0.18) * Math.PI / 2) * 1.25;
        else if (progress < 0.45) scale = 1.25 - ((progress - 0.18) / 0.27) * 0.25;
        else if (progress > 0.78) scale = 1.0 - ((progress - 0.78) / 0.22);
        item.sprite.position.set(item.x, item.y + (item.type === 'lively_angry' ? Math.sin(item.age * 60) * 0.1 : 0) + item.age * 0.4, item.z);
        let finalS = scale * item.initialScale;
        if (item.type === 'comic_speech' && item.aspect) {
            // Preserve readability: scale X by aspect ratio so the bubble keeps its shape
            item.sprite.scale.set(finalS * item.aspect, finalS, 1);
        } else {
            item.sprite.scale.set(finalS, finalS, 1);
        }
        item.sprite.material.opacity = progress > 0.78 ? (1.0 - (progress - 0.78) / 0.22) : 1.0;
    }
}

// ---------- END SCREENS ----------

function showEndScreen(kind) {
    const overlay = document.getElementById('end-screen');
    if (!overlay) return;
    const isWin = kind === 'victory';
    const title = isWin ? 'VICTORY' : 'DEFEAT';
    const sub   = isWin ? 'The realm honors your command, my liege.' : 'Your banner has fallen on the field.';
    const color = isWin ? '#ffd166' : '#ff4757';

    const allies = entities.filter(e => e.isPlayer && e.data.currentHp > 0).length;
    const enemiesLeft = entities.filter(e => !e.isPlayer && e.data.currentHp > 0).length;
    const keepsTaken = enemyBases.filter(b => b.destroyed).length;

    // ===== TOKEN GAME JAM 1 BADGE — shown on VICTORY only =====
    const jamBadge = isWin ? (
        '<div class="jam-badge">' +
            '<div class="jam-badge-row">' +
                '<span class="jam-spark">✨</span>' +
                '<span class="jam-title">Made for <b>Token Game Jam 1</b></span>' +
                '<span class="jam-spark">✨</span>' +
            '</div>' +
            '<div class="jam-tag">#TokenJam · An AI-crafted indie tale</div>' +
            '<div class="jam-thanks">Thanks to <b>Coeurnix</b> &amp; everyone in the jam community 💛<br>' +
                'Generative AI helped bring the Realm of Amoio to life — art, audio, code, and story.</div>' +
            '<a class="jam-link" href="https://itch.io/jam/token-jam-1" target="_blank" rel="noopener">View the jam on itch.io →</a>' +
        '</div>'
    ) : '';

    overlay.innerHTML =
        '<div class="end-card ' + (isWin ? 'win' : 'lose') + '">' +
            '<div class="end-banner" style="color:' + color + '">' + title + '</div>' +
            '<div class="end-sub">' + sub + '</div>' +
            '<div class="end-stats">' +
                '<div><span>🏰 Keeps Taken</span><b>' + keepsTaken + ' / ' + enemyBases.length + '</b></div>' +
                '<div><span>🛡️ Surviving Units</span><b>' + allies + '</b></div>' +
                '<div><span>☠️ Enemies Remaining</span><b>' + enemiesLeft + '</b></div>' +
                '<div><span>💎 Gems</span><b>' + gems + '</b></div>' +
            '</div>' +
            '<div class="end-stars">' + (isWin ? renderStars(keepsTaken, enemyBases.length, allies) : '☠️ ☠️ ☠️') + '</div>' +
            jamBadge +
            '<button class="btn large-btn" onclick="restartCampaign()">' + (isWin ? 'March Onward' : 'Rally Again') + '</button>' +
        '</div>';
    overlay.classList.remove('hidden');

    // Hide the surrender button once the match is over
    const giveBtn = document.getElementById('giveup-btn');
    if (giveBtn) giveBtn.classList.add('hidden');

    if (window.SFX) SFX.play(isWin ? 'victory' : 'defeat');
}

function renderStars(keepsTaken, total, allies) {
    let stars = 1;
    if (keepsTaken === total) stars = 2;
    if (keepsTaken === total && allies >= 3) stars = 3;
    return '⭐'.repeat(stars) + '☆'.repeat(3 - stars);
}

window.restartCampaign = restartCampaign;
function restartCampaign() {
    window.location.reload();
}

// ===========================================================
// UI VISIBILITY TOGGLE  (👁 button — hide / show the entire HUD)
// ===========================================================

var uiHidden = false;
window.toggleUIVisibility = toggleUIVisibility;
function toggleUIVisibility() {
    const layer = document.getElementById('ui-layer');
    const showTab = document.getElementById('ui-show-tab');
    if (!layer) return;
    uiHidden = !uiHidden;
    if (uiHidden) {
        layer.classList.add('ui-hidden');
        if (showTab) showTab.classList.remove('hidden');
    } else {
        layer.classList.remove('ui-hidden');
        if (showTab) showTab.classList.add('hidden');
    }
}

// ===========================================================
// SETTINGS / TUTORIAL MODAL
// ===========================================================

window.toggleSettings = toggleSettings;
function toggleSettings() {
    const modal = document.getElementById('settings-modal');
    if (!modal) return;
    if (modal.classList.contains('hidden')) modal.classList.remove('hidden');
    else modal.classList.add('hidden');
}

window.switchSettingsTab = switchSettingsTab;
function switchSettingsTab(tabName) {
    document.querySelectorAll('#settings-modal .tab-btn').forEach(b => {
        b.classList.toggle('active', b.getAttribute('data-tab') === tabName);
    });
    document.querySelectorAll('#settings-modal .tab-pane').forEach(p => {
        p.classList.toggle('active', p.id === 'tab-' + tabName);
    });
}

window.selectDeployedUnit = selectDeployedUnit;
function selectDeployedUnit(index) {
    selectedUnitIndex = index;
    commandMode = null;
    renderDeployedRoster();
    renderOrderPanel();
}

window.deselectUnit = deselectUnit;
function deselectUnit() {
    selectedUnitIndex = -1;
    commandMode = null;
    renderDeployedRoster();
    renderOrderPanel();
}

window.issueOrder = issueOrder;
function issueOrder(action) {
    if (selectedUnitIndex < 0 || !entities[selectedUnitIndex]) return;
    const e = entities[selectedUnitIndex];
    if (action === 'cancel') {
        e.order = null; e.orderTarget = null; e.miningPhase = null;
        if (window.setEntityOrderIcon) setEntityOrderIcon(e);
        commandMode = null;
        if (window.triggerSpeechBubble) triggerSpeechBubble("Standing by.", e.px, 5.0, e.pz, 'order', e);
    } else if (action === 'attack' || action === 'ping' || action === 'hold') {
        commandMode = action; // wait for map click
    } else {
        e.order = action;
        e.orderTarget = null;
        e.miningPhase = null;
        e._mineTarget = null;
        if (window.setEntityOrderIcon) setEntityOrderIcon(e);
        commandMode = null;
        // Have the unit *repeat* the command back, using their personality
        if (window.triggerSpeechBubble) {
            const orderPhrases = {
                defend: ["Defending the keep!", "Shields up!", "To the wall!"],
                mine:   ["On my way to mine!", "To the gems!", "Mining now!"],
                retreat:["Falling back!", "Retreat!", "To safety!"]
            };
            const personal = (PERSONALITY_LINES[e.data.type] && PERSONALITY_LINES[e.data.type][action === 'mine' ? 'mine' : 'obey']) || [];
            const pool = (personal.length ? personal : (orderPhrases[action] || ["Yes, sir!"]));
            const line = pool[Math.floor(Math.random() * pool.length)];
            triggerSpeechBubble(line, e.px, 5.0, e.pz, 'order', e);
        }
    }
    renderDeployedRoster();
    renderOrderPanel();
}

window.setEntityOrderIcon = setEntityOrderIcon;
function setEntityOrderIcon(e) {
    const icon = { attack: '⚔️', defend: '🛡️', retreat: '🏃', hold: '🚩', ping: '📍', mine: '⛏️' }[e.order];
    if (icon && window.triggerLivelyEmoji) {
        triggerLivelyEmoji(icon, e.px || e.sprite?.position.x || 0, 3.0, e.pz || e.sprite?.position.z || 0, 'normal_hit');
    }
}

window.issueAllMine = issueAllMine;
function issueAllMine() {
    let n = 0;
    entities.forEach(e => {
        if (e.isPlayer && e.data.loyalty > 20) {
            e.order = 'mine';
            e.orderTarget = null;
            e.miningPhase = null;
            e._mineTarget = null;
            if (window.setEntityOrderIcon) setEntityOrderIcon(e);
            // Stagger the bubble "Mining now!" lines so they don't overlap visually
            setTimeout(() => {
                if (e.data.currentHp > 0 && window.triggerSpeechBubble) {
                    const lines = (PERSONALITY_LINES[e.data.type]?.mine || ["Mining now!"]);
                    triggerSpeechBubble(lines[Math.floor(Math.random() * lines.length)], e.px, 5.0, e.pz, 'order', e);
                }
            }, n * 220);
            n++;
        }
    });
    showScreenToast(`⛏️ All Mine — ${n} unit${n === 1 ? '' : 's'} dispatched`, 'mine');
    renderDeployedRoster();
    if (selectedUnitIndex >= 0) renderOrderPanel();
}

// ===========================================================
// SCREEN-FIXED TOASTS  (DOM, camera-anchored — NOT in 3D world)
// Used for global command feedback so text never blocks the field.
// ===========================================================
window.showScreenToast = showScreenToast;
function showScreenToast(text, kind) {
    const stack = document.getElementById('screen-toast-stack');
    if (!stack) return;
    const el = document.createElement('div');
    el.className = 'screen-toast ' + (kind ? 'toast-' + kind : '');
    el.innerText = text;
    stack.appendChild(el);
    // Auto-remove after the CSS out-animation finishes (~1.8s total)
    setTimeout(() => { if (el.parentNode) el.parentNode.removeChild(el); }, 2000);
    // Cap stack length to avoid screen flood
    while (stack.children.length > 4) stack.removeChild(stack.firstChild);
}

// ---------- Global: ALL ATTACK ----------
window.issueAllAttack = issueAllAttack;
function issueAllAttack() {
    let n = 0;
    // Aim at the nearest non-destroyed enemy keep so they actually advance.
    let tx = 0, tz = -38;
    if (typeof enemyBases !== 'undefined' && enemyBases.length) {
        const alive = enemyBases.filter(b => !b.destroyed);
        if (alive.length) {
            // Pick the keep closest to the centroid of player units
            let cx = 0, cz = 0, c = 0;
            entities.forEach(e => { if (e.isPlayer && e.data.currentHp > 0) { cx += e.px; cz += e.pz; c++; } });
            if (c) { cx /= c; cz /= c; }
            let best = alive[0], bd = 1e9;
            for (const b of alive) {
                const d = Math.hypot(b.x - cx, b.z - cz);
                if (d < bd) { bd = d; best = b; }
            }
            tx = best.x; tz = best.z;
        }
    }
    entities.forEach(e => {
        if (!e.isPlayer || e.data.currentHp <= 0) return;
        if (e.data.loyalty < 20 && e.data.type !== 'machine') return;
        e.order = 'attack';
        e.orderTarget = { x: tx, z: tz };
        e.miningPhase = null;
        e._mineTarget = null;
        if (window.setEntityOrderIcon) setEntityOrderIcon(e);
        setTimeout(() => {
            if (e.data.currentHp > 0 && window.triggerSpeechBubble) {
                const lines = (PERSONALITY_LINES[e.data.type]?.attack || ["Attack!"]);
                triggerSpeechBubble(lines[Math.floor(Math.random() * lines.length)], e.px, 5.0, e.pz, 'attacker', e);
            }
        }, n * 180);
        n++;
    });
    showScreenToast(`⚔️ All Attack — ${n} unit${n === 1 ? '' : 's'} charging`, 'attack');
    renderDeployedRoster();
    if (selectedUnitIndex >= 0) renderOrderPanel();
}

// ---------- Global: ALL DEFEND ----------
window.issueAllDefend = issueAllDefend;
function issueAllDefend() {
    let n = 0;
    entities.forEach(e => {
        if (!e.isPlayer || e.data.currentHp <= 0) return;
        if (e.data.loyalty < 20 && e.data.type !== 'machine') return;
        e.order = 'defend';
        e.orderTarget = null;
        e.miningPhase = null;
        e._mineTarget = null;
        if (window.setEntityOrderIcon) setEntityOrderIcon(e);
        setTimeout(() => {
            if (e.data.currentHp > 0 && window.triggerSpeechBubble) {
                const lines = (PERSONALITY_LINES[e.data.type]?.defend || ["Defending!"]);
                triggerSpeechBubble(lines[Math.floor(Math.random() * lines.length)], e.px, 5.0, e.pz, 'order', e);
            }
        }, n * 180);
        n++;
    });
    showScreenToast(`🛡️ All Defend — ${n} unit${n === 1 ? '' : 's'} holding the line`, 'defend');
    renderDeployedRoster();
    if (selectedUnitIndex >= 0) renderOrderPanel();
}

// ---------- Global: ALL RETREAT ----------
window.issueAllRetreat = issueAllRetreat;
function issueAllRetreat() {
    let n = 0;
    entities.forEach(e => {
        if (!e.isPlayer || e.data.currentHp <= 0) return;
        // Cowards always flee (regardless of loyalty); machines always obey;
        // others need at least minimal loyalty
        if (e.data.type !== 'coward' && e.data.type !== 'machine' && e.data.loyalty < 20) return;
        e.order = 'retreat';
        e.orderTarget = null;
        e.miningPhase = null;
        e._mineTarget = null;
        if (window.setEntityOrderIcon) setEntityOrderIcon(e);
        setTimeout(() => {
            if (e.data.currentHp > 0 && window.triggerSpeechBubble) {
                const lines = (PERSONALITY_LINES[e.data.type]?.retreat || ["Falling back!"]);
                triggerSpeechBubble(lines[Math.floor(Math.random() * lines.length)], e.px, 5.0, e.pz, 'victim', e);
            }
        }, n * 180);
        n++;
    });
    showScreenToast(`🏃 Retreat — ${n} unit${n === 1 ? '' : 's'} falling back`, 'retreat');
    renderDeployedRoster();
    if (selectedUnitIndex >= 0) renderOrderPanel();
}

// ---------- Global: PRAISE (loyalty boost + visible feedback) ----------
window.issueAllPraise = issueAllPraise;
function issueAllPraise() {
    // PRAISE BOOST: +12 loyalty to all alive player units (capped at 100).
    // Previously this only set latestEmoji = '💖' which gave a 10% chance per
    // frame to add +5 loyalty — effectively invisible. Now it's a real, snappy
    // morale buff with bubble feedback so the player KNOWS it worked.
    let n = 0, totalBoost = 0;
    entities.forEach(e => {
        if (!e.isPlayer || e.data.currentHp <= 0) return;
        const before = e.data.loyalty;
        e.data.loyalty = Math.min(100, e.data.loyalty + 12);
        const gained = e.data.loyalty - before;
        if (gained > 0) totalBoost += gained;
        // Also briefly arm the '💖' aura so passive +5 ticks still happen for a moment
        n++;
        setTimeout(() => {
            if (e.data.currentHp > 0 && window.triggerSpeechBubble) {
                const lines = (PERSONALITY_LINES[e.data.type]?.praise || ["Thank you!", "💖"]);
                triggerSpeechBubble(lines[Math.floor(Math.random() * lines.length)], e.px, 5.0, e.pz, 'attacker', e);
            }
            if (e.data.currentHp > 0 && window.triggerLivelyEmoji) {
                triggerLivelyEmoji('💖', e.px, 2.4, e.pz, 'normal_hit', e);
            }
        }, n * 120);
    });
    latestEmoji = '💖';
    setTimeout(() => { if (latestEmoji === '💖') latestEmoji = null; }, 2500);
    if (n === 0) {
        showScreenToast('No troops to praise!', 'error');
    } else {
        showScreenToast(`💖 Praise — ${n} unit${n === 1 ? '' : 's'} cheered (+${Math.round(totalBoost / Math.max(1, n))} avg loyalty)`, 'praise');
    }
    renderDeployedRoster();
    if (selectedUnitIndex >= 0) renderOrderPanel();
}

